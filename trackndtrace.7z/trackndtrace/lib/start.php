<?php

	ob_start();
	session_start();
	set_time_limit(0);
?>
