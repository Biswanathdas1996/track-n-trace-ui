<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: OPTIONS,GET,POST,PUT,DELETE");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

date_default_timezone_set('Asia/Kolkata');

$currtime = date("Y-m-d h:i:s");
define("DBHOST","localhost");
define("DBNAME","trackndtrace");
define("DBUSER","root");
define("DBPASSWORD","");
define("SALT","123Abc!@#$%^&*");

?>