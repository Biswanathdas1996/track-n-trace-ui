<?php
include_once ('../lib/config.php');
include_once ('../lib/connect.php');
include ("../class/functions.php");
$functions = new functions(); 
$headers = apache_request_headers();
$user_token = $headers['auth_token'];
$postdata = file_get_contents("php://input");
$currtime = date("Y-m-d h:i:s");
$emptyarray = array();
$myObj = new StdClass;
$salt = SALT;
if(isset($postdata) && !empty($postdata))
{
	
	$data = json_decode($postdata);
	$product_name = $data->product_name;
	$category_id = $data->category_id;
	$subcategory_id = $data->subcategory_id;
	$product_image = $data->product_image;
	$product_attributes = $data->product_attributes;
	$product_id = $data->product_id;
	
	
	
	if(empty($product_name) || empty($category_id) || empty($subcategory_id) || empty($user_token) )
	{
		
		$myObj->status_code = '400';
		$myObj->message= "Mandatory fields empty";
		echo json_encode($myObj);
	}
	else
	{
		$verifyUser = $functions->verifyUser($user_token);
		if(!empty($verifyUser))
		{
		
		if(!empty($product_id))
		{
			$deleteProductAttributes =  $functions->deleteProductAttributes($product_id);
			$productDetailsByProductId =  $functions->productDetailsByProductId($product_id);
			
			if(!empty($product_image))
			{
				$bin = base64_decode($product_image);
				$imgnm = 'img'.time();
				file_put_contents('../product_images/'.$imgnm.'.png', $bin);
				$uploaded_image= SITE_URL.'product_images/'.$imgnm.'.png';
			}
			else
			{
				$uploaded_image= $productDetailsByProductId['product_image'];
			}
			
			
		   $updateProduct = $functions->updateProduct($product_id,$category_id,$subcategory_id,$product_name,$uploaded_image,$currtime);
		   if(!empty($product_attributes))
			{
				$product_attributes_array = json_decode(json_encode($product_attributes) , true);
				for ($i = 0;$i < count($product_attributes_array);$i++)
                {
                	$addProduct_attributes = $functions->addProduct_attributes($product_id,$product_attributes_array[$i]['value'],$currtime);

				}
			}
			
			if($updateProduct)
			{
				$myObj->status_code = '200';
				$myObj->message = 'Product Updated Successfully';
			}
			else
			{
				$myObj->status_code = '500';
				$myObj->message = 'Something went wrong';
			}
			
			echo json_encode($myObj);
			
		}
		else
		{
			
			
			
			if(!empty($product_image))
			{
				$bin = base64_decode($product_image);
				$imgnm = 'img'.time();
				file_put_contents('../product_images/'.$imgnm.'.png', $bin);
				$uploaded_image= SITE_URL.'product_images/'.$imgnm.'.png';
			}
			else
			{
				$uploaded_image= "";
			}
			
            
			$addNewProduct = $functions->addNewProduct($verifyUser['id'],'',$category_id,$subcategory_id,$product_name,$uploaded_image,$currtime);
		
			
			$last_id =  $functions->get_insert_id();
			$productDetailsById =  $functions->productDetailsById($last_id);
			
			
			$productcode = substr($productDetailsById['product_name'], 0,2).substr($productDetailsById['category_name'], 0,2).substr($productDetailsById['subcategory_name'], 0,2);
			$salted_cat_token= $last_id.$salt;
			/*$cat_token = md5($salted_cat_token);*/
			$product_token = $productcode.$last_id.time();
			$updateProductToken = $functions->updateProductToken($last_id,$product_token);
			
			if(!empty($product_attributes))
			{
				$product_attributes_array = json_decode(json_encode($product_attributes) , true);
				for ($i = 0;$i < count($product_attributes_array);$i++)
                {
                	$addProduct_attributes = $functions->addProduct_attributes($product_token,$product_attributes_array[$i]['value'],$currtime);

				}
			}
			
			if(!empty($last_id))
			{
				$myObj->status_code = '200';
				$myObj->product_id = $product_token;
				$myObj->message = 'Product Added Successfully';
			}
			else
			{
				$myObj->status_code = '500';
				$myObj->message = 'Something went wrong';
			}
			
			echo json_encode($myObj);
		}
		}
		else
		{
		  $myObj->status_code = '500';
		  $myObj->message = 'Invalid Authorization Token';
		  echo json_encode($myObj);
		}	
	}

}

else
{      
		
		$myObj->status_code = '400';
	    $myObj->message= "Mandatory fields empty";
		echo json_encode($myObj);
}
?>