<?php
include_once ('../lib/config.php');
include_once ('../lib/connect.php');
include ("../class/functions.php");
$functions = new functions(); 

$emptyarray = array();
$myObj = new StdClass;
$product_id = isset($_REQUEST['product_id'])?$_REQUEST['product_id']:'';
$productDetailsByProductId =  $functions->productDetailsByProductId($product_id);	
$productAttributes = $functions->productAttributes($product_id,'N');

if(!empty($productDetailsByProductId))
{

	$myObj->status_code = '200';
	$myObj->data = $productDetailsByProductId;
	$myObj->attributes = $productAttributes;
	$myObj->message = 'Data fetched successfully.';
    echo json_encode($myObj);

}
else
{
  $myObj->status_code = '500';
  $myObj->message = 'Failure unable to Fetch Data';
  echo json_encode($myObj);
}

?>