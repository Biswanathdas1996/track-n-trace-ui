<?php
include_once ('../lib/config.php');
include_once ('../lib/connect.php');
include ("../class/functions.php");
$functions = new functions();  

$postdata = file_get_contents("php://input");
$currtime = date("Y-m-d h:i:s");
$emptyarray = array();
$myObj = new StdClass;
$salt = SALT;
if(isset($postdata) && !empty($postdata))
{
	
	$data = json_decode($postdata);
	$email = $data->email;
	$password = $data->password;
	$saltedpass = md5(SALT.$password);
	
	if(empty($email) || empty($password))
	{
		
		$myObj->status_code = '400';
		$myObj->message= "Mandatory fields empty";
		echo json_encode($myObj);
	}
	else
	{
	$userlogin = $functions->user_Login($email,$saltedpass);
	
	

	if(!empty($userlogin))
	{
		
	    $salted_token = rand(1,50).$salt;
	    $token = md5($salted_token);
		$updateUsertoken = $functions->updateUsertoken($userlogin['id'],$token);
		$getZone = $functions->getZone($userlogin['state']);
		
		if($userlogin['user_role'] == '1')
		{
			$roleType = 'Manufacturer';
		}
		if($userlogin['user_role'] == '2')
		{
			$roleType = 'Distributer';
		}
		if($userlogin['user_role'] == '3')
		{
			$roleType = 'Retailer';
		}
		
		$userdata = array("user_fname" => $userlogin['user_fname'],"user_lname" => $userlogin['user_lname'],"user_token" => $userlogin['user_token'],"user_email" => $userlogin['user_email'],"user_phone" => $userlogin['user_phone'],"user_role" => $userlogin['user_role'],"role_type" => $roleType,"state_code" => $userlogin['state'],"state_name" => $getZone['state_name'],"zone" => $userlogin['zone'],"user_id" => $userlogin['id']);
		
		$myObj->status_code = '200';
		$myObj->data = $userdata;
		$myObj->message = 'Login Successful';

	}
	else
	{
		
		$myObj->status_code = '400';
		$myObj->errormessage= "Invalid login";
	}
	
	echo json_encode($myObj);
	}
	
	
	
	
	
}

else
{

	$myObj->success = '0';
	$myObj->errormessage= "Data fields are empty";
	echo json_encode($myObj);
}
?>