<?php
include_once ('../lib/config.php');
include_once ('../lib/connect.php');
include ("../class/functions.php");
$functions = new functions(); 
$headers = apache_request_headers();
$user_token = $headers['auth_token'];
$postdata = file_get_contents("php://input");
$currtime = date("Y-m-d h:i:s");
$emptyarray = array();
$myObj = new StdClass;
$salt = SALT;
if(isset($postdata) && !empty($postdata))
{
	
	$data = json_decode($postdata);
	$sub_category_name = $data->sub_category_name;
	$category_id = $data->category_id;
	$sub_category_id = $data->sub_category_id;
	
	
	
	
	if(empty($sub_category_name) || empty($category_id) || empty($user_token) )
	{
		
		$myObj->status_code = '400';
		$myObj->message= "Mandatory fields empty";
		echo json_encode($myObj);
	}
	else
	{
		$verifyUser = $functions->verifyUser($user_token);
		if(!empty($verifyUser))
		{
		
		if(!empty($sub_category_id))
		{
			$updateSubCategory = $functions->updateSubCategory($sub_category_id,$category_id,$sub_category_name,$currtime);
			
			if($updateSubCategory)
			{
				$myObj->status_code = '200';
				$myObj->message = 'Sub Category Updated Successfully';
			}
			else
			{
				$myObj->status_code = '500';
				$myObj->message = 'Something went wrong';
			}
			
			echo json_encode($myObj);
			
		}
		else
		{
			$addNewSubCategory = $functions->addNewSubCategory($verifyUser['id'],$category_id,'',$sub_category_name,$currtime);
			
			$last_id =  $functions->get_insert_id();
			$salted_subcat_token= $last_id.$salt;
			/*$subcat_token = md5($salted_subcat_token);*/
			$subcat_token = $last_id.time();
			$updateSubCatToken = $functions->updateSubCatToken($last_id,$subcat_token);
			
			if(!empty($last_id))
			{
				$myObj->status_code = '200';
				$myObj->sub_cat_id = $subcat_token;
				$myObj->message = 'Sub Category Added Successfully';
			}
			else
			{
				$myObj->status_code = '500';
				$myObj->message = 'Something went wrong';
			}
			
			echo json_encode($myObj);
		}
		}
		else
		{
		  $myObj->status_code = '500';
		  $myObj->message = 'Invalid Authorization Token';
		  echo json_encode($myObj);
		}	
	}

}

else
{      
		
		$myObj->status_code = '400';
	    $myObj->message= "Mandatory fields empty";
		echo json_encode($myObj);
}
?>