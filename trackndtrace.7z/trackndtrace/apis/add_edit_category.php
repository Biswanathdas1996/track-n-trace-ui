<?php
include_once ('../lib/config.php');
include_once ('../lib/connect.php');
include ("../class/functions.php");
$functions = new functions(); 
$headers = apache_request_headers();
$user_token = $headers['auth_token'];
$postdata = file_get_contents("php://input");
$currtime = date("Y-m-d h:i:s");
$emptyarray = array();
$myObj = new StdClass;
$salt = SALT;
if(isset($postdata) && !empty($postdata))
{
	
	$data = json_decode($postdata);
	$category_name = $data->category_name;
	$category_id = $data->category_id;
	
	
	
	if(empty($category_name) || empty($user_token)  )
	{
		
		$myObj->status_code = '400';
		$myObj->message= "Mandatory fields empty";
		echo json_encode($myObj);
	}
	else
	{
		
		$verifyUser = $functions->verifyUser($user_token);
		
		if(!empty($verifyUser))
		{
		if(!empty($category_id))
		{
			$updateCategory = $functions->updateCategory($category_id,$category_name,$currtime);
			
			if($updateCategory)
			{
				$myObj->status_code = '200';
				$myObj->message = 'Category Updated Successfully';
			}
			else
			{
				$myObj->status_code = '500';
				$myObj->message = 'Something went wrong';
			}
			
			echo json_encode($myObj);
			
		}
		else
		{
			$addNewCategory = $functions->addNewCategory('',$verifyUser['id'],$category_name,$currtime);
			
			$last_id =  $functions->get_insert_id();
			$salted_cat_token= $last_id.$salt;
			/*$cat_token = md5($salted_cat_token);*/
			$cat_token = $last_id.time();
			$updateCatToken = $functions->updateCatToken($last_id,$cat_token);
			
			if(!empty($last_id))
			{
				$myObj->status_code = '200';
				$myObj->cat_id = $cat_token;
				$myObj->message = 'Category Added Successfully';
			}
			else
			{
				$myObj->status_code = '500';
				$myObj->message = 'Something went wrong';
			}
			
			echo json_encode($myObj);
		}
		}
		else
		{
		  $myObj->status_code = '500';
		  $myObj->message = 'Invalid Authorization Token';
		  echo json_encode($myObj);
		}	
		

	}

}

else
{      
		
		$myObj->status_code = '400';
	    $myObj->message= "Mandatory fields empty";
		echo json_encode($myObj);
}
?>