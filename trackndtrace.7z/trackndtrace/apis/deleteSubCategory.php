<?php
include_once ('../lib/config.php');
include_once ('../lib/connect.php');
include ("../class/functions.php");
$functions = new functions(); 


$postdata = file_get_contents("php://input");
$currtime = date("Y-m-d h:i:s");
$emptyarray = array();
$myObj = new StdClass;
$salt = SALT;
if(isset($postdata) && !empty($postdata))
{
	
	$data = json_decode($postdata);
	$sub_category_id = $data->subcategory_id;
	
	
	
	if(empty($sub_category_id) )
	{
		
		$myObj->status_code = '400';
		$myObj->message= "Mandatory fields empty";
		
		echo json_encode($myObj);
	}
	else
	{
		
		if(!empty($sub_category_id))
		{
			$deleteSubCategory = $functions->deleteSubCategory($sub_category_id,$currtime);
			
			if($deleteSubCategory)
			{
				$myObj->status_code = '200';
				$myObj->message = 'Category deleted Successfully';
			}
			else
			{
				$myObj->status_code = '500';
				$myObj->message = 'Something went wrong';
			}
			
			echo json_encode($myObj);
			
		}
		

	}

}

else
{      
		
		$myObj->status_code = '400';
	    $myObj->message= "Mandatory fields empty";
		echo json_encode($myObj);
}
?>