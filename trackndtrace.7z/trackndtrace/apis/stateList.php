<?php
include_once ('../lib/config.php');
include_once ('../lib/connect.php');
include ("../class/functions.php");
$functions = new functions(); 

$emptyarray = array();
$myObj = new StdClass;

/*$stateid = $_REQUEST['stateid'];
echo $stateid;*/
$stateList = $functions->stateList('N');	

if(!empty($stateList))
{
	$successarray = array(
	"status_code" => '200',
	"stateList" => $stateList,
	"message"  => 'Data fetched successfully.'
	);
echo json_encode($successarray);

}
else
{
  $myObj->status_code = '500';
  $myObj->message = 'Failure unable to Fetch Data';
  echo json_encode($myObj);
}

?>