<?php
include_once ('../lib/config.php');
include_once ('../lib/connect.php');
include ("../class/functions.php");
$functions = new functions(); 

$emptyarray = array();
$myObj = new StdClass;
$auth_token = isset($_REQUEST['auth_token'])?$_REQUEST['auth_token']:'';

if(!empty($auth_token))
	
{
	$verifyUser = $functions->verifyUser($auth_token);
	
		

if(!empty($verifyUser))
{
	
		$getZone = $functions->getZone($verifyUser['state']);

		if($verifyUser['user_role'] == '1')
		{
			$roleType = 'Manufacturer';
		}
		if($verifyUser['user_role'] == '2')
		{
			$roleType = 'Distributer';
		}
		if($verifyUser['user_role'] == '3')
		{
			$roleType = 'Retailer';
		}
				
		
		$userdata = array("user_fname" => $verifyUser['user_fname'],"user_lname" => $verifyUser['user_lname'],"user_token" => $verifyUser['user_token'],"user_email" => $verifyUser['user_email'],"user_phone" => $verifyUser['user_phone'],"user_role" => $verifyUser['user_role'],"role_type" => $roleType,"state_code" => $verifyUser['state'],"state_name" => $getZone['state_name'],"zone" => $verifyUser['zone'],"user_id" => $verifyUser['id']);
		
		
		
		$myObj->status_code = '200';
		$myObj->data = $userdata;
		$myObj->message = ' Authorization Token Verified';
		echo json_encode($myObj);
}
else
{
  $myObj->status_code = '500';
  $myObj->message = 'Invalid Authorization Token';
  echo json_encode($myObj);
}
}
else
	
{
	$myObj->status_code = '400';
	$myObj->message= "Authorization Token empty";
	echo json_encode($myObj);
}


?>