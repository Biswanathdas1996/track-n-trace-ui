<?php
include_once ('../lib/config.php');
include_once ('../lib/connect.php');
include ("../class/functions.php");
$functions = new functions(); 

$emptyarray = array();
$myObj = new StdClass;
$cat_id = isset($_REQUEST['cat_id'])?$_REQUEST['cat_id']:'';
$categoryDetails = $functions->categoryDetails($cat_id);	

if(!empty($categoryDetails))
{

	$myObj->status_code = '200';
	$myObj->data = $categoryDetails;
	$myObj->message = 'Data fetched successfully.';
    echo json_encode($myObj);

}
else
{
  $myObj->status_code = '500';
  $myObj->message = 'Failure unable to Fetch Data';
  echo json_encode($myObj);
}

?>