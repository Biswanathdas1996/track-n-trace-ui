<?php
include_once ('../lib/config.php');
include_once ('../lib/connect.php');
include ("../class/functions.php");
$functions = new functions(); 
$headers = apache_request_headers();
$user_token = $headers['auth_token'];
$emptyarray = array();
$myObj = new StdClass;
$dataarray = array();
$verifyUser = $functions->verifyUser($user_token);
$productList = $functions->productList($verifyUser['id'],'N');	
	
 
if(!empty($productList))
{
	
	foreach ($productList AS $productListVAL)
	{
		$productAttributes = $functions->productAttributes($productListVAL['product_id'],'N');
		
		$data = array("productid" => $productListVAL['product_id'],"product_name" => $productListVAL['product_name'],"product_image" => $productListVAL['product_image'],"category_name" => $productListVAL['category_name'],"subcategory_name" => $productListVAL['subcategory_name'],"created" => $productListVAL['created'],"attributes" => $productAttributes);
		
		array_push($dataarray,$data);
	}
	
	$successarray = array(
	"status_code" => '200',
	"productList" => $dataarray,
	"message"  => 'Data fetched successfully.'
	);
echo json_encode($successarray);

}
else
{
  $myObj->status_code = '500';
  $myObj->message = 'Failure unable to Fetch Data';
  echo json_encode($myObj);
}

?>