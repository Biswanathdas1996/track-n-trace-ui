<?php
include_once ('../lib/config.php');
include_once ('../lib/connect.php');
include ("../class/functions.php");
$functions = new functions(); 
$headers = apache_request_headers();
$user_token = $headers['auth_token'];
$emptyarray = array();
$myObj = new StdClass;
$cat_id = isset($_REQUEST['cat_id'])?$_REQUEST['cat_id']:'';
$verifyUser = $functions->verifyUser($user_token);
$categoryList = $functions->categoryList($cat_id,$verifyUser['id'],'N');	

if(!empty($categoryList))
{
	$successarray = array(
	"status_code" => '200',
	"categoryList" => $categoryList,
	"message"  => 'Data fetched successfully.'
	);
echo json_encode($successarray);

}
else
{
  $myObj->status_code = '500';
  $myObj->message = 'Failure unable to Fetch Data';
  echo json_encode($myObj);
}

?>