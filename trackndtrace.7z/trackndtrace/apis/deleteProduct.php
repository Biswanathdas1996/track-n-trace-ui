<?php
include_once ('../lib/config.php');
include_once ('../lib/connect.php');
include ("../class/functions.php");
$functions = new functions(); 


$postdata = file_get_contents("php://input");
$currtime = date("Y-m-d h:i:s");
$emptyarray = array();
$myObj = new StdClass;
$salt = SALT;
if(isset($postdata) && !empty($postdata))
{
	
	$data = json_decode($postdata);
	$product_id = $data->product_id;
	
	
	
	if(empty($product_id) )
	{
		
		$myObj->status_code = '400';
		$myObj->message= "Mandatory fields empty";
		
		echo json_encode($myObj);
	}
	else
	{
		
		if(!empty($product_id))
		{
			$deleteProduct = $functions->deleteProduct($product_id,$currtime);
			$deleteProductAttributes =  $functions->deleteProductAttributes($product_id);
			
			if($deleteProduct)
			{
				$myObj->status_code = '200';
				$myObj->message = 'Product deleted Successfully';
			}
			else
			{
				$myObj->status_code = '500';
				$myObj->message = 'Something went wrong';
			}
			
			echo json_encode($myObj);
			
		}
		

	}

}

else
{      
		
		$myObj->status_code = '400';
	    $myObj->message= "Mandatory fields empty";
		echo json_encode($myObj);
}
?>