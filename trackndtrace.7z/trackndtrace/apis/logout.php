<?php
include_once ('../lib/config.php');
include_once ('../lib/connect.php');
include ("../class/functions.php");
$functions = new functions(); 
$headers = apache_request_headers();
$user_token = $headers['auth_token'];
$myObj = new StdClass;
	if( empty($user_token)  )
	{
		
		$myObj->status_code = '400';
		$myObj->message= "Authorization Token empty";
		echo json_encode($myObj);
	}
	else
	{
		
		$verifyUser = $functions->verifyUser($user_token);
		
		if(!empty($verifyUser))
		{
		  $updateUsertoken = $functions->updateUsertoken($verifyUser['id'],'');
		  	if($updateUsertoken)
			{
				$myObj->status_code = '200';
				$myObj->message = 'User Logged Out Successfully';
			}
			else
			{
				$myObj->status_code = '500';
				$myObj->message = 'Something went wrong';
			}
			
			echo json_encode($myObj);
		}
		else
		{
		  $myObj->status_code = '500';
		  $myObj->message = 'Invalid Authorization Token';
		  echo json_encode($myObj);
		}	
		

	}
?>