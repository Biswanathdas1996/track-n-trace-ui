<?php
include_once ('../lib/config.php');
include_once ('../lib/connect.php');
include ("../class/functions.php");
$functions = new functions(); 


$postdata = file_get_contents("php://input");
$currtime = date("Y-m-d h:i:s");
$emptyarray = array();
$myObj = new StdClass;
$salt = SALT;
if(isset($postdata) && !empty($postdata))
{
	
	$data = json_decode($postdata);
	$user_fname = $data->user_fname;
	$user_lname = $data->user_lname;
	$user_email = $data->user_email;
	$password = $data->user_password;
	$user_phoneno = $data->user_phoneno;
	$state_code = $data->state_code;
	$role = $data->role;
	$saltedpass = md5(SALT.$password);
	
	
	if(empty($user_fname) || empty($user_lname) || empty($password) || empty($user_phoneno) || empty($state_code) || empty($role) || empty($user_email) )
	{
		
		$myObj->status_code = '400';
		$myObj->message= "Mandatory fields empty";
		echo json_encode($myObj);
	}
	else
	{

	$CheckPhoneExits = $functions->CheckPhoneExits($user_phoneno);
	$CheckEmailExits = $functions->CheckEmailExits($user_email);
	
	if(!empty($CheckPhoneExits))
	{
		
		$myObj->status_code = '500';
		$myObj->message = 'Phone No. Already Exists';
		echo json_encode($myObj);
	}
    elseif(!empty($CheckEmailExits))
	{
		
		$myObj->status_code = '500';
		$myObj->message = 'Email Already Exists';
		echo json_encode($myObj);
	}
	else
	{
	$getZone = $functions->getZone($state_code);
	$AddNewUser = $functions->addNewUser('',$user_fname,$user_lname,$user_email,$user_phoneno,$saltedpass,$role,$state_code,$getZone['zone'],$currtime,$currtime);
	$last_id =  $functions->get_insert_id();
	
	
	$salted_token= $last_id.$salt;
	$token = md5($salted_token);
	$updateUsertoken = $functions->updateUsertoken($last_id,$token);
	if(!empty($last_id))
	{
		
		if($role == '1')
		{
			$roleType = 'Manufacturer';
		}
		if($role == '2')
		{
			$roleType = 'Distributer';
		}
		if($role == '3')
		{
			$roleType = 'Retailer';
		}
		
		
	    $userdata = array("user_fname" => $user_fname,"user_lname" => $user_lname,"user_token" => $token,"user_email" => $user_email,"user_phone" => $user_phoneno,"user_role" => $role,"role_type" => $roleType,"state_code" => $state_code,"state_name" => $getZone['state_name'],"zone" => $getZone['zone'],"user_id" => $last_id);
		
		$myObj->status_code = '200';
		$myObj->data = $userdata;
		$myObj->message = 'User Registration Successful';
		
   
	}
	else
	{
		
		$myObj->status_code = '500';
		$myObj->message = 'Something went wrong';
	}
	
	echo json_encode($myObj);
	
	}

	}

}

else
{      
		
		$myObj->status_code = '400';
	    $myObj->message= "Mandatory fields empty";
		echo json_encode($myObj);
}
?>