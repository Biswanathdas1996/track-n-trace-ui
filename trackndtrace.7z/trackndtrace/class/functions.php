<?php
class functions extends Db

{


	public function stateList($paginate = "N")
	{

        $sql = "SELECT `id` AS state_id, `state_code` , `state_name`, `zone` FROM `states` WHERE `delflag` = 'N' ";

      

        $result = $this->execute_query($sql);

        $arrayLists = array();

        if ($this->get_num_rows($result) > 0)

        {

            if ($paginate == "N")

            {

                while ($row = $result->fetch_assoc())
                {

                    $arrayLists[] = $row;

                }

            }

            else

            {

                global $num_rows, $p, $start, $list, $other_params, $num, $page;

                $list = ROW_PER_PAGE;

                $num_rows = $this->get_num_rows($result);

                $p = isset($_REQUEST['p']) ? trim($_REQUEST['p']) : 1;

                $num = ceil($num_rows / $list);

                $page = CUR_PAGE_NAME;

                $start = $list * ($p - 1);

                $i = 0;

                while ($row = $this->fetch_data($result))

                {

                    if ($i >= $start && $i < ($start + $list))

                    {

                        $arrayLists[] = $row;

                    }

                    $i++;

                }

            }

            return $arrayLists;

        }

        else

        {

            return 0;

        }

    }

    public function getZone($state_code)

    {

        $sql = "SELECT * FROM `states` WHERE `state_code`='$state_code'  AND `delflag` = 'N' ";
        
       

        $con = $this->con;

        $result = $con->query($sql);

        if ($result->num_rows > 0)

        {

            $rslt = $result->fetch_array(MYSQLI_ASSOC);

            return $rslt;

        }

        else

        {

            return "0";

        }

    }

    public function user_Login($user_email, $password)
    {

        $sql = "SELECT * FROM `users` WHERE

                    `user_email`='$user_email'

                    AND `user_password`='$password'

                    AND `delflag`='N'
                    

                    ";

        $con = $this->con;

        $result = $con->query($sql);

        if ($result->num_rows > 0)

        {

            $rslt = $result->fetch_array(MYSQLI_ASSOC);

            return $rslt;

        }

        else

        {

            return "0";

        }

    }

    public function addNewUser($user_token, $user_fname, $user_lname, $user_email, $user_phone, $user_password, $user_role,$state,$zone,$created,$modified)

    {

        $sql = "INSERT INTO `users` SET 
                    `user_token` = '$user_token',
                    `user_fname` = '$user_fname',
                    `user_lname` = '$user_lname',
                    `user_email` = '$user_email',                 
                    `user_phone` = '$user_phone' ,                                
                    `user_password` = '$user_password' ,                                
                    `user_role` = '$user_role' ,                                
                    `state` = '$state' ,                                
                    `zone` = '$zone' ,                                
                    `created` = '$created',                
                    `modified` = '$modified' ,               
                    `delflag` = 'N'                  
                    ";
			
        $con = $this->con;

        return $result = $con->query($sql);

    }

    public function CheckPhoneExits($user_phone)

    {

        $sql = "SELECT * FROM `users` WHERE `user_phone`='$user_phone'  AND `delflag` = 'N' ";

        $con = $this->con;

        $result = $con->query($sql);

        if ($result->num_rows > 0)

        {

            $rslt = $result->fetch_array(MYSQLI_ASSOC);

            return $rslt;

        }

        else

        {

            return "0";

        }

    }

    public function CheckEmailExits($user_email)

    {

        $sql = "SELECT * FROM `users` WHERE  `user_email` = '$user_email' AND `delflag` = 'N' ";

        $con = $this->con;

        $result = $con->query($sql);

        if ($result->num_rows > 0)

        {

            $rslt = $result->fetch_array(MYSQLI_ASSOC);

            return $rslt;

        }

        else

        {

            return "0";

        }

    }

    public function updateUsertoken($user_id, $token)
    {
        $sql = "UPDATE `users` SET
		       `user_token`= '$token'				
		      	WHERE  `id` = '$user_id'
				";

        return $this->execute_query($sql);
    }
    
    public function categoryList($catid,$user_id,$paginate = "N")
	{

        $sql = "SELECT `cat_id` AS category_id, `category_name` , `created` FROM `category` WHERE `delflag` = 'N' ";
        
           if(!empty($catid))
           {
           	
           	$sql .= " AND `cat_id` = '$catid' ";
           	
           }
           if(!empty($user_id))
           {
           	
           	$sql .= " AND `user_id` = '$user_id' ";
           	
           }
        
         $sql .= "ORDER BY `created` ASC ";

       

        $result = $this->execute_query($sql);

        $arrayLists = array();

        if ($this->get_num_rows($result) > 0)

        {

            if ($paginate == "N")

            {

                while ($row = $result->fetch_assoc())
                {

                    $arrayLists[] = $row;

                }

            }

            else

            {

                global $num_rows, $p, $start, $list, $other_params, $num, $page;

                $list = ROW_PER_PAGE;

                $num_rows = $this->get_num_rows($result);

                $p = isset($_REQUEST['p']) ? trim($_REQUEST['p']) : 1;

                $num = ceil($num_rows / $list);

                $page = CUR_PAGE_NAME;

                $start = $list * ($p - 1);

                $i = 0;

                while ($row = $this->fetch_data($result))

                {

                    if ($i >= $start && $i < ($start + $list))

                    {

                        $arrayLists[] = $row;

                    }

                    $i++;

                }

            }

            return $arrayLists;

        }

        else

        {

            return 0;

        }

    }
    
    public function addNewCategory($cat_id,$user_id, $category_name,$created)

    {

        $sql = "INSERT INTO `category` SET 
                    `cat_id` = '$cat_id',
                    `user_id` = '$user_id',
                    `category_name` = '$category_name',                          
                    `created` = '$created',                           
                    `delflag` = 'N'                  
                    ";
			
        $con = $this->con;

        return $result = $con->query($sql);

    }
    
     public function updateCatToken($id, $cat_id)
    {
        $sql = "UPDATE `category` SET
		       `cat_id`= '$cat_id'				
		      	WHERE  `id` = '$id'
				";

        return $this->execute_query($sql);
    }
    
      public function updateCategory($id, $category_name,$created)
    {
        $sql = "UPDATE `category` SET
		       `category_name`= '$category_name',				
		       `created`= '$created'				
		      	WHERE  `cat_id` = '$id'
				";

        return $this->execute_query($sql);
    }
    
       public function deleteCategory($id,$created)
    {
        $sql = "UPDATE `category` SET
		       `delflag`= 'Y',				
		       `created`= '$created'				
		      	WHERE  `cat_id` = '$id'
				";

        return $this->execute_query($sql);
    }
   
       public function addNewSubCategory($user_id,$category_id, $subcat_id,$subcategory_name,$created)

    {

        $sql = "INSERT INTO `subcategory` SET
         
                    `user_id` = '$user_id',
                    `category_id` = '$category_id',
                    `subcat_id` = '$subcat_id',
                    `subcategory_name` = '$subcategory_name',                          
                    `created` = '$created',                           
                    `delflag` = 'N'                  
                    ";
			
        $con = $this->con;

        return $result = $con->query($sql);

    }
    
         public function updateSubCatToken($id, $subcat_id)
    {
        $sql = "UPDATE `subcategory` SET
		       `subcat_id`= '$subcat_id'				
		      	WHERE  `id` = '$id'
				";

        return $this->execute_query($sql);
    }
    
          public function updateSubCategory($id, $category_id,$subcategory_name,$created)
    {
        $sql = "UPDATE `subcategory` SET
		       `category_id`= '$category_id',				
		       `subcategory_name`= '$subcategory_name',				
		       `created`= '$created'				
		      	WHERE  `subcat_id` = '$id'
				";

        return $this->execute_query($sql);
    }
    
      public function sub_categoryList($user_id,$subcat_id,$paginate = "N")
	{

        $sql = "SELECT `category_id`,`category_name`,sub_category_id,`subcategory_name`,`created`  FROM ( SELECT `user_id`, `category_id`,`subcat_id` AS sub_category_id, `subcategory_name` , `created` FROM `subcategory` WHERE `delflag` = 'N' ";
        
           if(!empty($subcat_id))
           {
           	
           	$sql .= " AND `subcat_id` = '$subcat_id' ";
           	
           }
           if(!empty($user_id))
           {
           	
           	$sql .= " AND `user_id` = '$user_id' ";
           	
           }
        
         $sql .= " )SUBCAT INNER JOIN (SELECT `cat_id`, `category_name` FROM `category`)CAT ON  SUBCAT.`category_id` = CAT.`cat_id` ORDER BY SUBCAT.`created` ASC ";

       

        $result = $this->execute_query($sql);

        $arrayLists = array();

        if ($this->get_num_rows($result) > 0)

        {

            if ($paginate == "N")

            {

                while ($row = $result->fetch_assoc())
                {

                    $arrayLists[] = $row;

                }

            }

            else

            {

                global $num_rows, $p, $start, $list, $other_params, $num, $page;

                $list = ROW_PER_PAGE;

                $num_rows = $this->get_num_rows($result);

                $p = isset($_REQUEST['p']) ? trim($_REQUEST['p']) : 1;

                $num = ceil($num_rows / $list);

                $page = CUR_PAGE_NAME;

                $start = $list * ($p - 1);

                $i = 0;

                while ($row = $this->fetch_data($result))

                {

                    if ($i >= $start && $i < ($start + $list))

                    {

                        $arrayLists[] = $row;

                    }

                    $i++;

                }

            }

            return $arrayLists;

        }

        else

        {

            return 0;

        }

    }
    
    public function deleteSubCategory($id,$created)
    {
        $sql = "UPDATE `subcategory` SET
		       `delflag`= 'Y',				
		       `created`= '$created'				
		      	WHERE  `subcat_id` = '$id'
				";

        return $this->execute_query($sql);
    }
    
    public function addNewProduct($user_id,$product_id, $category_id,$subcategory_id,$product_name,$product_image,$created)

    {

        $sql = "INSERT INTO `product` SET
        			`user_id`  = '$user_id',
                    `product_id` = '$product_id',
                    `category_id` = '$category_id',
                    `subcategory_id` = '$subcategory_id',                          
                    `product_name` = '$product_name',                          
                    `product_image` = '$product_image',                          
                    `created` = '$created',                           
                    `delflag` = 'N'                  
                    ";
			
        $con = $this->con;

        return $result = $con->query($sql);

    }
    
       public function addProduct_attributes($product_id, $attributes,$created)

    {

        $sql = "INSERT INTO `product_attributes` SET 
                    `product_id` = '$product_id',
                    `attributes` = '$attributes',                         
                    `created` = '$created',                           
                    `delflag` = 'N'                  
                    ";
			
        $con = $this->con;

        return $result = $con->query($sql);

    }
    
       public function updateProductToken($id, $product_id)
    {
        $sql = "UPDATE `product` SET
		       `product_id`= '$product_id'				
		      	WHERE  `id` = '$id'
				";

        return $this->execute_query($sql);
    }
    
      public function productDetailsById($id)

    {

        $sql = "SELECT * FROM ( SELECT * FROM ( SELECT * FROM  `product` WHERE  `id` = '$id' AND `delflag` = 'N')PRDUCT INNER JOIN (SELECT `cat_id`, `category_name` FROM `category`)CATS ON PRDUCT.`category_id` = CATS.`cat_id`)PRODUCTCATS INNER JOIN (SELECT `subcat_id`, `subcategory_name` FROM `subcategory`)SUBCATS ON  PRODUCTCATS.`subcategory_id` = SUBCATS.`subcat_id` ";

        $con = $this->con;

        $result = $con->query($sql);

        if ($result->num_rows > 0)

        {

            $rslt = $result->fetch_array(MYSQLI_ASSOC);

            return $rslt;

        }

        else

        {

            return "0";

        }

    }
    
    public function deleteProductAttributes($id)
    {
        $sql = "UPDATE `product_attributes` SET
		       `delflag`= 'Y'				
		      	WHERE  `product_id` = '$id'
				";

        return $this->execute_query($sql);
    }
    
          public function productDetailsByProductId($id)

    {

        $sql = "SELECT * FROM ( SELECT * FROM ( SELECT * FROM  `product` WHERE  `product_id` = '$id' AND `delflag` = 'N')PRDUCT INNER JOIN (SELECT `cat_id`, `category_name` FROM `category`)CATS ON PRDUCT.`category_id` = CATS.`cat_id`)PRODUCTCATS INNER JOIN (SELECT `subcat_id`, `subcategory_name` FROM `subcategory`)SUBCATS ON  PRODUCTCATS.`subcategory_id` = SUBCATS.`subcat_id` ";

        $con = $this->con;

        $result = $con->query($sql);

        if ($result->num_rows > 0)

        {

            $rslt = $result->fetch_array(MYSQLI_ASSOC);

            return $rslt;

        }

        else

        {

            return "0";

        }

    }
    
        public function updateProduct($product_id, $category_id,$subcategory_id,$product_name,$product_image,$created)

    {

        $sql = "UPDATE `product` SET 
                    
                    `category_id` = '$category_id',
                    `subcategory_id` = '$subcategory_id',                          
                    `product_name` = '$product_name',                          
                    `product_image` = '$product_image',                          
                    `created` = '$created'
                    WHERE   `product_id` = '$product_id'       
                    ";
			
        $con = $this->con;

        return $result = $con->query($sql);

    }
    
       public function productList($user_id,$paginate = "N")
	{

       $sql = "SELECT * FROM ( SELECT * FROM ( SELECT * FROM  `product` WHERE  `delflag` = 'N'";
        
        if(!empty($user_id))
           {
           	
           	$sql .= " AND `user_id` = '$user_id' ";
           	
           }
       
      $sql .= " )PRDUCT INNER JOIN (SELECT `cat_id`, `category_name` FROM `category`)CATS ON PRDUCT.`category_id` = CATS.`cat_id`)PRODUCTCATS INNER JOIN (SELECT `subcat_id`, `subcategory_name` FROM `subcategory`)SUBCATS ON  PRODUCTCATS.`subcategory_id` = SUBCATS.`subcat_id` ";

       

        $result = $this->execute_query($sql);

        $arrayLists = array();

        if ($this->get_num_rows($result) > 0)

        {

            if ($paginate == "N")

            {

                while ($row = $result->fetch_assoc())
                {

                    $arrayLists[] = $row;

                }

            }

            else

            {

                global $num_rows, $p, $start, $list, $other_params, $num, $page;

                $list = ROW_PER_PAGE;

                $num_rows = $this->get_num_rows($result);

                $p = isset($_REQUEST['p']) ? trim($_REQUEST['p']) : 1;

                $num = ceil($num_rows / $list);

                $page = CUR_PAGE_NAME;

                $start = $list * ($p - 1);

                $i = 0;

                while ($row = $this->fetch_data($result))

                {

                    if ($i >= $start && $i < ($start + $list))

                    {

                        $arrayLists[] = $row;

                    }

                    $i++;

                }

            }

            return $arrayLists;

        }

        else

        {

            return 0;

        }

    }
    
        public function productAttributes($productid,$paginate = "N")
	{

       $sql = " SELECT `attributes` FROM  `product_attributes` WHERE  `delflag` = 'N' AND `product_id` = '$productid'";

       

        $result = $this->execute_query($sql);

        $arrayLists = array();

        if ($this->get_num_rows($result) > 0)

        {

            if ($paginate == "N")

            {

                while ($row = $result->fetch_assoc())
                {

                    $arrayLists[] = $row;

                }

            }

            else

            {

                global $num_rows, $p, $start, $list, $other_params, $num, $page;

                $list = ROW_PER_PAGE;

                $num_rows = $this->get_num_rows($result);

                $p = isset($_REQUEST['p']) ? trim($_REQUEST['p']) : 1;

                $num = ceil($num_rows / $list);

                $page = CUR_PAGE_NAME;

                $start = $list * ($p - 1);

                $i = 0;

                while ($row = $this->fetch_data($result))

                {

                    if ($i >= $start && $i < ($start + $list))

                    {

                        $arrayLists[] = $row;

                    }

                    $i++;

                }

            }

            return $arrayLists;

        }

        else

        {

            return 0;

        }

    }
    
    public function deleteProduct($id,$created)
    {
        $sql = "UPDATE `product` SET
		       `delflag`= 'Y',				
		       `created`= '$created'				
		      	WHERE  `product_id` = '$id'
				";

        return $this->execute_query($sql);
    }
    
    public function categoryDetails($catid)
    {

        $sql = "SELECT `cat_id` AS category_id, `category_name` , `created` FROM `category` WHERE `delflag` = 'N' AND `cat_id` = '$catid' ";


        $con = $this->con;

        $result = $con->query($sql);

        if ($result->num_rows > 0)

        {

            $rslt = $result->fetch_array(MYSQLI_ASSOC);

            return $rslt;

        }

        else

        {

            return "0";

        }

    }
    
         public function sub_categoryDetails($subcat_id)
	{

        $sql = "SELECT `category_id`,`category_name`,sub_category_id,`subcategory_name`,`created`  FROM ( SELECT `category_id`,`subcat_id` AS sub_category_id, `subcategory_name` , `created` FROM `subcategory` WHERE `delflag` = 'N' AND `subcat_id` = '$subcat_id' ";
        
         $sql .= " )SUBCAT INNER JOIN (SELECT `cat_id`, `category_name` FROM `category`)CAT ON  SUBCAT.`category_id` = CAT.`cat_id` ORDER BY SUBCAT.`created` ASC ";

       $con = $this->con;

        $result = $con->query($sql);

        if ($result->num_rows > 0)

        {

            $rslt = $result->fetch_array(MYSQLI_ASSOC);

            return $rslt;

        }

        else

        {

            return "0";

        }

       

    }
    
    public function verifyUser($user_token)
    {

        $sql = "SELECT * FROM `users` WHERE

                    `user_token`='$user_token' AND `delflag`='N' ";
                    
                    

        $con = $this->con;

        $result = $con->query($sql);

        if ($result->num_rows > 0)

        {

            $rslt = $result->fetch_array(MYSQLI_ASSOC);

            return $rslt;

        }

        else

        {

            return "0";

        }

    }
   
}

?>