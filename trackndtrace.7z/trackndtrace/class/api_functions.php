<?php
class api_functions extends Db

{

    public function user_Login($user_email, $password)
    {

        $sql = "SELECT * FROM `user` WHERE

                    `email`='$user_email'

                    AND `password`='$password'

                    AND `delflag`='N'
                    

                    ";

        $con = $this->con;

        $result = $con->query($sql);

        if ($result->num_rows > 0)

        {

            $rslt = $result->fetch_array(MYSQLI_ASSOC);

            return $rslt;

        }

        else

        {

            return "0";

        }

    }

    public function AddNewUser($user_name, $email, $phone, $password, $gender, $created, $modified)

    {

        $sql = "INSERT INTO `user` SET 
                    `user_name` = '$user_name',
                    `email` = '$email',
                    `phone_no` = '$phone',
                    `password` = '$password',                 
                    `gender` = '$gender' ,                                
                    `created` = '$created',                
                    `modified` = '$modified' ,               
                    `delflag` = 'N'                  
                    ";
			
        $con = $this->con;

        return $result = $con->query($sql);

    }

    public function CheckPhoneEmailExits($phone_no, $email)

    {

        $sql = "SELECT * FROM `user` WHERE `phone_no`='$phone_no' AND `email` = '$email' AND `delflag` = 'N' ";

        $con = $this->con;

        $result = $con->query($sql);

        if ($result->num_rows > 0)

        {

            $rslt = $result->fetch_array(MYSQLI_ASSOC);

            return $rslt;

        }

        else

        {

            return "0";

        }

    }

    public function updateUsertoken($user_id, $token)
    {
        $sql = "UPDATE `user` SET
		       `user_token`= '$token'				
		      	WHERE  `id` = '$user_id'
				";

        return $this->execute_query($sql);
    }
    
    public function categoryList($paginate = "N")
	{

        $sql = "SELECT `id` AS cat_id, `category_code` AS cat_code,`category_name` AS cat_name,`category_thumb_image` AS cat_thumb_img, `category_original_image` AS cat_original_img  FROM `category` WHERE `delflag` = 'N' ";

        $sql .= "ORDER BY `id` DESC ";

        $result = $this->execute_query($sql);

        $adminLists = array();

        if ($this->get_num_rows($result) > 0)

        {

            if ($paginate == "N")

            {

                while ($row = $result->fetch_assoc())
                {

                    $adminLists[] = $row;

                }

            }

            else

            {

                global $num_rows, $p, $start, $list, $other_params, $num, $page;

                $list = ROW_PER_PAGE;

                $num_rows = $this->get_num_rows($result);

                $p = isset($_REQUEST['p']) ? trim($_REQUEST['p']) : 1;

                $num = ceil($num_rows / $list);

                $page = CUR_PAGE_NAME;

                $start = $list * ($p - 1);

                $i = 0;

                while ($row = $this->fetch_data($result))

                {

                    if ($i >= $start && $i < ($start + $list))

                    {

                        $adminLists[] = $row;

                    }

                    $i++;

                }

            }

            return $adminLists;

        }

        else

        {

            return 0;

        }

    }

	public function subCategoryList($parentcat, $paginate = "N")
	{

    $sql = "SELECT
    sub_cat_id,
    sub_cat_code,
    parent_category_id,
    parent_cat_name,
    sub_cat_name,
    sub_cat_thumb_img,
    sub_cat_original_img
FROM
    (
    SELECT
        `id` AS sub_cat_id,
        `subcategory_code` AS sub_cat_code,
        `parent_category` ,
        `sub_categoryname` AS sub_cat_name,
        `subcategory_thumb_image` AS sub_cat_thumb_img,
        `subcategory_original_image` AS sub_cat_original_img
    FROM
        `subcategory`
    WHERE
        `delflag` = 'N' AND `parent_category` = '$parentcat'
) SUBCATEGORY
INNER JOIN(
    SELECT
        `id` AS parent_category_id,
        `category_name` AS parent_cat_name
    FROM
        `category`
) CATEGORY
ON
    SUBCATEGORY.`parent_category` = CATEGORY.parent_category_id ";

        $sql .= "ORDER BY SUBCATEGORY.sub_cat_id DESC ";

        $result = $this->execute_query($sql);

        $adminLists = array();

        if ($this->get_num_rows($result) > 0)

        {

            if ($paginate == "N")

            {

                while ($row = $result->fetch_assoc())
                {

                    $adminLists[] = $row;

                }

            }

            else

            {

                global $num_rows, $p, $start, $list, $other_params, $num, $page;

                $list = ROW_PER_PAGE;

                $num_rows = $this->get_num_rows($result);

                $p = isset($_REQUEST['p']) ? trim($_REQUEST['p']) : 1;

                $num = ceil($num_rows / $list);

                $page = CUR_PAGE_NAME;

                $start = $list * ($p - 1);

                $i = 0;

                while ($row = $this->fetch_data($result))

                {

                    if ($i >= $start && $i < ($start + $list))

                    {

                        $adminLists[] = $row;

                    }

                    $i++;

                }

            }

            return $adminLists;

        }

        else

        {

            return 0;

        }

    }



	public function bannerList($paginate = "N")
	{

        $sql = "SELECT `id` AS banner_id, `banner_img_thumb` AS banner_thumb_img, `banner_img_original` AS banner_original_img FROM `banner` WHERE `delflag` = 'N' ";

      

        $result = $this->execute_query($sql);

        $adminLists = array();

        if ($this->get_num_rows($result) > 0)

        {

            if ($paginate == "N")

            {

                while ($row = $result->fetch_assoc())
                {

                    $adminLists[] = $row;

                }

            }

            else

            {

                global $num_rows, $p, $start, $list, $other_params, $num, $page;

                $list = ROW_PER_PAGE;

                $num_rows = $this->get_num_rows($result);

                $p = isset($_REQUEST['p']) ? trim($_REQUEST['p']) : 1;

                $num = ceil($num_rows / $list);

                $page = CUR_PAGE_NAME;

                $start = $list * ($p - 1);

                $i = 0;

                while ($row = $this->fetch_data($result))

                {

                    if ($i >= $start && $i < ($start + $list))

                    {

                        $adminLists[] = $row;

                    }

                    $i++;

                }

            }

            return $adminLists;

        }

        else

        {

            return 0;

        }

    }
	public function materialList($paginate = "N")
	{

        $sql = "SELECT `id` AS material_id, `material_name`,`material_code`,`material_price_gram` FROM `materials` WHERE `delflag` = 'N' ";

      

        $result = $this->execute_query($sql);

        $adminLists = array();

        if ($this->get_num_rows($result) > 0)

        {

            if ($paginate == "N")

            {

                while ($row = $result->fetch_assoc())
                {

                    $adminLists[] = $row;

                }

            }

            else

            {

                global $num_rows, $p, $start, $list, $other_params, $num, $page;

                $list = ROW_PER_PAGE;

                $num_rows = $this->get_num_rows($result);

                $p = isset($_REQUEST['p']) ? trim($_REQUEST['p']) : 1;

                $num = ceil($num_rows / $list);

                $page = CUR_PAGE_NAME;

                $start = $list * ($p - 1);

                $i = 0;

                while ($row = $this->fetch_data($result))

                {

                    if ($i >= $start && $i < ($start + $list))

                    {

                        $adminLists[] = $row;

                    }

                    $i++;

                }

            }

            return $adminLists;

        }

        else

        {

            return 0;

        }

    }
    
    
    public function productList($product_category,$product_subcategory,$product_name,$product_materials,$product_keywords,$product_gender,$price_sort,$maxprice,$minprice,$userid, $paginate = "N")
	{
    
    $sql = "";
    
    if(!empty($userid))
    {
		 $sql .= "SELECT * FROM ( ";
	}
   
    
     
    $sql .= "  SELECT * FROM `products` WHERE `delflag`='N' AND `status` = '1' ";
    
           if(!empty($product_category))
           {
		   	$sql .= "AND `product_category` = '$product_category' ";
		   } 
		   if(!empty($product_subcategory))
           {
		   	$sql .= "AND `product_subcategory` IN ($product_subcategory) ";
		   }
		    if(!empty($product_name))
           {
		   	$sql .= "AND `product_name`  LIKE '%$product_name%' ";
		   }
		    if(!empty($product_materials))
           {
		   	$sql .= "AND `product_materials`  IN ($product_materials) ";
		   }
           if(!empty($product_keywords))
           {
		   	$sql .= "AND `product_keywords`  LIKE '%$product_keywords%' ";
		   }
		    if(!empty($product_gender))
           {
		   	$sql .= "AND `product_gender` =  '$product_gender' ";
		   }
		   
		    if(!empty($minprice))
           {
		   	$sql .= "AND `product_total_price` >=  '$minprice' ";
		   }
		   
		    if(!empty($maxprice))
           {
		   	$sql .= "AND `product_total_price` <=  '$maxprice' ";
		   }
		   if(!empty($userid))
		   {
		   	 $sql .= ")PRODUCTTABLE LEFT OUTER JOIN (SELECT `id` AS wishList_id ,`user_id`,`product_id` AS PRDCTID,`favourite_flag`,`created` AS wishlist_added_on FROM `user_wishlist` WHERE `user_id` = '$userid' AND `delflag`= 'N'  )USERWISHLIST ON PRODUCTTABLE.`id` =   USERWISHLIST.PRDCTID   ";
		   }
		   
			 if(!empty($price_sort))
           {
           	  if($price_sort == '1')
           	  
           	  {
			  	$sql .= "ORDER BY `product_total_price` DESC ";
			  }
			  
			  if($price_sort == '2')
           	  
           	  {
			  	$sql .= "ORDER BY `product_total_price` ASC ";
			  }
           	
		   
		   }
		   else
		   {
		   	$sql .= "ORDER BY `id` DESC ";
		   }
        
        
      
        $result = $this->execute_query($sql);

        $adminLists = array();

        if ($this->get_num_rows($result) > 0)

        {

            if ($paginate == "N")

            {

                while ($row = $result->fetch_assoc())
                {

                    $adminLists[] = $row;

                }

            }

            else

            {

                global $num_rows, $p, $start, $list, $other_params, $num, $page;

                $list = ROW_PER_PAGE;

                $num_rows = $this->get_num_rows($result);

                $p = isset($_REQUEST['p']) ? trim($_REQUEST['p']) : 1;

                $num = ceil($num_rows / $list);

                $page = CUR_PAGE_NAME;

                $start = $list * ($p - 1);

                $i = 0;

                while ($row = $this->fetch_data($result))

                {

                    if ($i >= $start && $i < ($start + $list))

                    {

                        $adminLists[] = $row;

                    }

                    $i++;

                }

            }

            return $adminLists;

        }

        else

        {

            return 0;

        }

    }


	public function productMaterials($productid,$paginate = "N")
	{

        $sql = "SELECT `material_name`,`material_code`,`material_weight`,`material_price_gram`,`material_total` AS total_material_price FROM `product_material` WHERE `product_id`  = '$productid' ";

      

        $result = $this->execute_query($sql);

        $adminLists = array();

        if ($this->get_num_rows($result) > 0)

        {

            if ($paginate == "N")

            {

                while ($row = $result->fetch_assoc())
                {

                    $adminLists[] = $row;

                }

            }

            else

            {

                global $num_rows, $p, $start, $list, $other_params, $num, $page;

                $list = ROW_PER_PAGE;

                $num_rows = $this->get_num_rows($result);

                $p = isset($_REQUEST['p']) ? trim($_REQUEST['p']) : 1;

                $num = ceil($num_rows / $list);

                $page = CUR_PAGE_NAME;

                $start = $list * ($p - 1);

                $i = 0;

                while ($row = $this->fetch_data($result))

                {

                    if ($i >= $start && $i < ($start + $list))

                    {

                        $adminLists[] = $row;

                    }

                    $i++;

                }

            }

            return $adminLists;

        }

        else

        {

            return 0;

        }

    }


	public function productImages($productid,$paginate = "N")
	{

        $sql = "SELECT `product_image` FROM `product_images` WHERE `product_id`  = '$productid' ";

      

        $result = $this->execute_query($sql);

        $adminLists = array();

        if ($this->get_num_rows($result) > 0)

        {

            if ($paginate == "N")

            {

                while ($row = $result->fetch_assoc())
                {

                    $adminLists[] = $row;

                }

            }

            else

            {

                global $num_rows, $p, $start, $list, $other_params, $num, $page;

                $list = ROW_PER_PAGE;

                $num_rows = $this->get_num_rows($result);

                $p = isset($_REQUEST['p']) ? trim($_REQUEST['p']) : 1;

                $num = ceil($num_rows / $list);

                $page = CUR_PAGE_NAME;

                $start = $list * ($p - 1);

                $i = 0;

                while ($row = $this->fetch_data($result))

                {

                    if ($i >= $start && $i < ($start + $list))

                    {

                        $adminLists[] = $row;

                    }

                    $i++;

                }

            }

            return $adminLists;

        }

        else

        {

            return 0;

        }

    }

     public function productDetailsById($productid)

    {

        $sql = "SELECT
        `id` AS product_id,
    `product_name`,
    product_cat,
    product_subcat,
    `product_code`,
    `product_weight`,
    `product_description`,
    `product_total_price`,
    `product_keywords`,
    `product_thumb_image`,
    `size_chart` FROM
    (
    SELECT
        *
    FROM
        (
        SELECT
            *
        FROM
            `products`
        WHERE
            `delflag` = 'N' AND `id` = '$productid'
    ) PRODUCT
INNER JOIN(
    SELECT
        `id` AS CATID,
        `category_name` AS product_cat
    FROM
        `category`
) CATEGORY
ON
    PRODUCT.`product_category` = CATEGORY.CATID
)PRODUCTCAT
INNER JOIN
(
    SELECT
        `id` AS SUBCATID,
        `sub_categoryname` AS product_subcat
    FROM
        `subcategory`
) SUBCATEGORY
ON
    PRODUCTCAT.`product_subcategory` = SUBCATEGORY.SUBCATID ";

        $con = $this->con;

        $result = $con->query($sql);

        if ($result->num_rows > 0)

        {

            $rslt = $result->fetch_array(MYSQLI_ASSOC);

            return $rslt;

        }

        else

        {

            return "0";

        }

    }


	public function UserDetailsByToken($usertoken)

    {

        $sql = " SELECT * FROM `user` WHERE `user_token` = '$usertoken' ";


        $con = $this->con;

        $result = $con->query($sql);

        if ($result->num_rows > 0)

        {

            $rslt = $result->fetch_array(MYSQLI_ASSOC);

            return $rslt;

        }

        else

        {

            return "0";

        }

    }

  public function UserDetails($usertoken)

    {

        $sql = " SELECT `user_token`,`user_name`,`email`,`phone_no`,`gender`,`created`,`modified` FROM `user` WHERE `user_token` = '$usertoken' ";

    
        $con = $this->con;

        $result = $con->query($sql);

        if ($result->num_rows > 0)

        {

            $rslt = $result->fetch_array(MYSQLI_ASSOC);

            return $rslt;

        }

        else

        {

            return "0";

        }

    }

	public function AddUserWishlist($user_id, $product_id, $favourite_flag,$created)

    {

        $sql = "INSERT INTO `user_wishlist` SET 
                    `user_id` = '$user_id',
                    `product_id` = '$product_id',
                    `favourite_flag` = '$favourite_flag',                             
                    `created` = '$created',                         
                    `delflag` = 'N'                  
                    ";
			
			
        $con = $this->con;

        return $result = $con->query($sql);

    }


    public function UserWishList($userid, $paginate = "N")
	{

    $sql = "SELECT * FROM ( SELECT * FROM `products` WHERE `delflag`='N' AND `status` = '1' ";
    $sql .= ")PRODUCTTABLE INNER JOIN (SELECT `id` AS wishList_id ,`user_id`,`product_id` AS PRDCTID,`favourite_flag`,`created` AS wishlist_added_on FROM `user_wishlist` WHERE `user_id` = '$userid' AND `delflag`= 'N'  )USERWISHLIST ON PRODUCTTABLE.`id` =   USERWISHLIST.PRDCTID  ORDER BY USERWISHLIST.wishList_id DESC ";

      
    
        $result = $this->execute_query($sql);

        $adminLists = array();

        if ($this->get_num_rows($result) > 0)

        {

            if ($paginate == "N")

            {

                while ($row = $result->fetch_assoc())
                {

                    $adminLists[] = $row;

                }

            }

            else

            {

                global $num_rows, $p, $start, $list, $other_params, $num, $page;

                $list = ROW_PER_PAGE;

                $num_rows = $this->get_num_rows($result);

                $p = isset($_REQUEST['p']) ? trim($_REQUEST['p']) : 1;

                $num = ceil($num_rows / $list);

                $page = CUR_PAGE_NAME;

                $start = $list * ($p - 1);

                $i = 0;

                while ($row = $this->fetch_data($result))

                {

                    if ($i >= $start && $i < ($start + $list))

                    {

                        $adminLists[] = $row;

                    }

                    $i++;

                }

            }

            return $adminLists;

        }

        else

        {

            return 0;

        }

    }

	public function productWhishlistDetailsById($wishlistid)

    {

        $sql = "SELECT `id` AS wishlist_id,`favourite_flag`,`created` FROM `user_wishlist` WHERE `id` = '$wishlistid'";

        $con = $this->con;

        $result = $con->query($sql);

        if ($result->num_rows > 0)

        {

            $rslt = $result->fetch_array(MYSQLI_ASSOC);

            return $rslt;

        }

        else

        {

            return "0";

        }

    }


  	public function productWhishlistDetailsByUserId($userid,$productid)

    {

        $sql = "SELECT `id` AS wishlist_id,`favourite_flag`,`created` FROM `user_wishlist` WHERE `user_id` = '$userid'  AND `product_id`='$productid' AND `delflag`= 'N' ";

        $con = $this->con;

        $result = $con->query($sql);

        if ($result->num_rows > 0)

        {

            $rslt = $result->fetch_array(MYSQLI_ASSOC);

            return $rslt;

        }

        else

        {

            return "0";

        }

    }


	public function DeleteUserWishlistProduct($wishlist_id)

    {

         $sql = "UPDATE `user_wishlist` SET
		       `delflag`= 'Y'				
		      	WHERE  `id` = '$wishlist_id'
				";
			
			
        $con = $this->con;

        return $result = $con->query($sql);

    }
    
    
    public function AddproductToCart($product_id, $user_id, $quantity, $total_price, $created, $modified)

    {

        $sql = "INSERT INTO `add_to_cart` SET 
                    `product_id` = '$product_id',
                    `user_id` = '$user_id',
                    `quantity` = '$quantity',
                    `total_price` = '$total_price',                                                
                    `created` = '$created',                
                    `modified` = '$modified' ,               
                    `delflag` = 'N'                  
                    ";
			
        $con = $this->con;

        return $result = $con->query($sql);

    }

  public function UserCartlist($userid, $paginate = "N")
	{

   $sql = "SELECT `id` AS cart_id, `product_id` , `quantity` , `total_price` , `created` FROM  `add_to_cart`  WHERE `user_id` = '$userid' AND `delflag`= 'N'  ";
  

      
    
        $result = $this->execute_query($sql);

        $adminLists = array();

        if ($this->get_num_rows($result) > 0)

        {

            if ($paginate == "N")

            {

                while ($row = $result->fetch_assoc())
                {

                    $adminLists[] = $row;

                }

            }

            else

            {

                global $num_rows, $p, $start, $list, $other_params, $num, $page;

                $list = ROW_PER_PAGE;

                $num_rows = $this->get_num_rows($result);

                $p = isset($_REQUEST['p']) ? trim($_REQUEST['p']) : 1;

                $num = ceil($num_rows / $list);

                $page = CUR_PAGE_NAME;

                $start = $list * ($p - 1);

                $i = 0;

                while ($row = $this->fetch_data($result))

                {

                    if ($i >= $start && $i < ($start + $list))

                    {

                        $adminLists[] = $row;

                    }

                    $i++;

                }

            }

            return $adminLists;

        }

        else

        {

            return 0;

        }

    }

   
     public function product_shortDetailsById($productid)

    {

        $sql = "SELECT `id` AS `product_id`,`product_name`,`product_weight`,`product_total_price`,`product_thumb_image` FROM `products` WHERE `id` = '$productid'" ;

        $con = $this->con;

        $result = $con->query($sql);

        if ($result->num_rows > 0)

        {

            $rslt = $result->fetch_array(MYSQLI_ASSOC);

            return $rslt;

        }

        else

        {

            return "0";

        }

    }
    
       public function Check_CartAlreadyexists($user_id,$productid)

    {

        $sql = "SELECT `id` AS cart_id, `product_id` , `quantity` , `total_price` , `created` FROM  `add_to_cart`  WHERE `user_id` = '$user_id' AND `delflag`= 'N' AND `product_id` = '$productid' ";
        
        

        $con = $this->con;

        $result = $con->query($sql);

        if ($result->num_rows > 0)

        {

            $rslt = $result->fetch_array(MYSQLI_ASSOC);

            return $rslt;

        }

        else

        {

            return "0";

        }

    }
    
    
  public function cart_DetailsById($cartid)

    {

        $sql = "SELECT * FROM `add_to_cart` WHERE `id` = '$cartid'" ;

        $con = $this->con;

        $result = $con->query($sql);

        if ($result->num_rows > 0)

        {

            $rslt = $result->fetch_array(MYSQLI_ASSOC);

            return $rslt;

        }

        else

        {

            return "0";

        }

    }

	public function Add_SubtractCartListProduct($quantity,$total_price,$cartid)

    {

         $sql = "UPDATE `add_to_cart` SET
		       `quantity`= '$quantity',
		       `total_price`= '$total_price'
		       				
		      	WHERE  `id` = '$cartid'
				";
			
			
        $con = $this->con;

        return $result = $con->query($sql);

    }

	public function delete_Cart($cartid)

    {

         $sql = "UPDATE `add_to_cart` SET
		       `delflag`= 'Y'
		        WHERE  `id` = '$cartid'
				";
			
			
        $con = $this->con;

        return $result = $con->query($sql);

    }
    
    
        public function Add_user_address($user_id, $full_name, $mobile_number,$pincode, $flat_house_no, $area_street, $landmark,$town_city,$state,$default_address_flag,$created, $modified)

    {

        $sql = "INSERT INTO `user_address` SET 
                    `user_id` = '$user_id',
                    `full_name` = '$full_name',
                    `mobile_number` = '$mobile_number',
                    `pincode` = '$pincode',                 
                    `flat_house_no` = '$flat_house_no' ,                                
                    `area_street` = '$area_street' ,                                
                    `landmark` = '$landmark' ,                                
                    `town_city` = '$town_city' ,                                
                    `state` = '$state' ,                                
                    `default_address_flag` = '$default_address_flag' ,                                
                    `created` = '$created',                
                    `modified` = '$modified' ,               
                    `delflag` = 'N'                  
                    ";
			
        $con = $this->con;

        return $result = $con->query($sql);

    }


	   public function Update_user_address($user_id, $full_name, $mobile_number,$pincode, $flat_house_no, $area_street, $landmark,$town_city,$state,$default_address_flag, $modified,$addressid)

    {

        $sql = "UPDATE `user_address` SET 
                    `user_id` = '$user_id',
                    `full_name` = '$full_name',
                    `mobile_number` = '$mobile_number',
                    `pincode` = '$pincode',                 
                    `flat_house_no` = '$flat_house_no' ,                                
                    `area_street` = '$area_street' ,                                
                    `landmark` = '$landmark' ,                                
                    `town_city` = '$town_city' ,                                
                    `state` = '$state' ,                                
                    `default_address_flag` = '$default_address_flag' ,                                             
                    `modified` = '$modified' ,               
                    `delflag` = 'N'   WHERE   `id` = '$addressid'               
                    ";
			
        $con = $this->con;

        return $result = $con->query($sql);

    }


	public function remove_Default_Address_Flag($user_id)

    {

         $sql = "UPDATE `user_address` SET
		       `default_address_flag`= '0'
		        WHERE  `user_id` = '$user_id'
				";
			
			
        $con = $this->con;

        return $result = $con->query($sql);

    }

   public function address_DetailsById($addressid)

    {

        $sql = "SELECT * FROM `user_address` WHERE `id` = '$addressid'" ;

        $con = $this->con;

        $result = $con->query($sql);

        if ($result->num_rows > 0)

        {

            $rslt = $result->fetch_array(MYSQLI_ASSOC);

            return $rslt;

        }

        else

        {

            return "0";

        }

    }


	public function delete_address($addressid)

    {

         $sql = "UPDATE `user_address` SET
		       `delflag`= 'Y'
		        WHERE  `id` = '$addressid'
				";
			
			
        $con = $this->con;

        return $result = $con->query($sql);

    }

	public function update_default_address($addressid,$default_address_flag)

    {

         $sql = "UPDATE `user_address` SET
		       `default_address_flag`= '$default_address_flag'
		        WHERE  `id` = '$addressid'
				";
			
			
        $con = $this->con;

        return $result = $con->query($sql);

    }


	  public function UserAddressList($userid, $paginate = "N")
	{

    $sql = "SELECT `id` AS address_id, `full_name`,`mobile_number`,`pincode`,`flat_house_no`,`area_street`,`landmark`,`town_city`,`state`,`default_address_flag` FROM `user_address` WHERE `user_id` = '$userid' AND `delflag`='N'";

      
    
        $result = $this->execute_query($sql);

        $adminLists = array();

        if ($this->get_num_rows($result) > 0)

        {

            if ($paginate == "N")

            {

                while ($row = $result->fetch_assoc())
                {

                    $adminLists[] = $row;

                }

            }

            else

            {

                global $num_rows, $p, $start, $list, $other_params, $num, $page;

                $list = ROW_PER_PAGE;

                $num_rows = $this->get_num_rows($result);

                $p = isset($_REQUEST['p']) ? trim($_REQUEST['p']) : 1;

                $num = ceil($num_rows / $list);

                $page = CUR_PAGE_NAME;

                $start = $list * ($p - 1);

                $i = 0;

                while ($row = $this->fetch_data($result))

                {

                    if ($i >= $start && $i < ($start + $list))

                    {

                        $adminLists[] = $row;

                    }

                    $i++;

                }

            }

            return $adminLists;

        }

        else

        {

            return 0;

        }

    }
    
    
      	 public function Place_order($user_id,$order_id, $order_total, $order_address,$order_status, $order_payment_type, $order_transaction_id,$created, $modified)

         {

        $sql = "INSERT INTO `orders` SET 
                    `user_id` = '$user_id',
                    `order_id` = '$order_id',
                    `order_total` = '$order_total',
                    `order_address` = '$order_address',
                    `order_status` = '$order_status',                 
                    `order_payment_type` = '$order_payment_type' ,                                
                    `order_transaction_id` = '$order_transaction_id' ,                                                              
                    `created` = '$created',                
                    `modified` = '$modified' ,               
                    `delflag` = 'N'                  
                    ";
			
        $con = $this->con;

        return $result = $con->query($sql);

    }

 public function Add_order_products($order_id,$product_id, $product_quantity,$product_total,$product_comments,$created)

    {

        $sql = "INSERT INTO `order_products` SET 
                    `order_id` = '$order_id',
                    `product_id` = '$product_id',
                    `product_quantity` = '$product_quantity',
                    `product_total` = '$product_total',                 
                    `product_comments` = '$product_comments',                 
                                                                                  
                    `created` = '$created'             
                                 
                    ";
			
        $con = $this->con;

        return $result = $con->query($sql);

    }



 	 public function update_order($order_id, $order_total, $id)

    {

        $sql = "UPDATE `orders` SET 
                    `order_id` = '$order_id',
                    `order_total` = '$order_total' WHERE `id` = '$id'
                    
                    ";
			
        $con = $this->con;

        return $result = $con->query($sql);

    }






 public function UserOrderlist($userid, $paginate = "N")
	{

   $sql = "SELECT  order_id,order_code,`order_total`,`order_status`,`order_payment_type`,`order_transaction_id`,`order_invoice` ,`created`,`full_name`,`mobile_number`,`pincode`,`flat_house_no`,`area_street`,`landmark`,`town_city`,`state` FROM (SELECT `id` AS order_id,`order_id` AS order_code,`order_total`,`order_address`,`order_status`,`order_payment_type`,`order_transaction_id`,`order_invoice`,`created` FROM `orders` WHERE `user_id` = '$userid' )ORDERDATA INNER JOIN ( SELECT `id` AS address_id,`full_name`,`mobile_number`,`pincode`,`flat_house_no`,`area_street`,`landmark`,`town_city`,`state` FROM `user_address`)ADDRESSDETAILS ON ORDERDATA.`order_address` = ADDRESSDETAILS.address_id ";
  

      
    
        $result = $this->execute_query($sql);

        $adminLists = array();

        if ($this->get_num_rows($result) > 0)

        {

            if ($paginate == "N")

            {

                while ($row = $result->fetch_assoc())
                {

                    $adminLists[] = $row;

                }

            }

            else

            {

                global $num_rows, $p, $start, $list, $other_params, $num, $page;

                $list = ROW_PER_PAGE;

                $num_rows = $this->get_num_rows($result);

                $p = isset($_REQUEST['p']) ? trim($_REQUEST['p']) : 1;

                $num = ceil($num_rows / $list);

                $page = CUR_PAGE_NAME;

                $start = $list * ($p - 1);

                $i = 0;

                while ($row = $this->fetch_data($result))

                {

                    if ($i >= $start && $i < ($start + $list))

                    {

                        $adminLists[] = $row;

                    }

                    $i++;

                }

            }

            return $adminLists;

        }

        else

        {

            return 0;

        }

    }


 public function UserOrderDetailsID($order_id, $paginate = "N")
	{

   $sql = "SELECT  order_id,order_code,`order_total`,`order_status`,`order_payment_type`,`order_transaction_id` ,`created`,`full_name`,`mobile_number`,`pincode`,`flat_house_no`,`area_street`,`landmark`,`town_city`,`state` FROM (SELECT `id` AS order_id,`order_id` AS order_code,`order_total`,`order_address`,`order_status`,`order_payment_type`,`order_transaction_id`,`created` FROM `orders` WHERE  `id` = '$order_id' )ORDERDATA INNER JOIN ( SELECT `id` AS address_id,`full_name`,`mobile_number`,`pincode`,`flat_house_no`,`area_street`,`landmark`,`town_city`,`state` FROM `user_address`)ADDRESSDETAILS ON ORDERDATA.`order_address` = ADDRESSDETAILS.address_id ";
  

      
    
        $result = $this->execute_query($sql);

        $adminLists = array();

        if ($this->get_num_rows($result) > 0)

        {

            if ($paginate == "N")

            {

                while ($row = $result->fetch_assoc())
                {

                    $adminLists[] = $row;

                }

            }

            else

            {

                global $num_rows, $p, $start, $list, $other_params, $num, $page;

                $list = ROW_PER_PAGE;

                $num_rows = $this->get_num_rows($result);

                $p = isset($_REQUEST['p']) ? trim($_REQUEST['p']) : 1;

                $num = ceil($num_rows / $list);

                $page = CUR_PAGE_NAME;

                $start = $list * ($p - 1);

                $i = 0;

                while ($row = $this->fetch_data($result))

                {

                    if ($i >= $start && $i < ($start + $list))

                    {

                        $adminLists[] = $row;

                    }

                    $i++;

                }

            }

            return $adminLists;

        }

        else

        {

            return 0;

        }

    }


public function OrderProductlist($orderid, $paginate = "N")
	{

   $sql = "SELECT `product_name`,`product_code`,`product_weight`,`gst_flag`,`service_tax`,`discount`,`product_description`,`product_total_price`,`product_thumb_image`,`product_quantity`,`product_total` AS product_order_price FROM ( SELECT * FROM `order_products` WHERE `order_id` = '$orderid')ORDERDATA INNER JOIN (SELECT `id` AS PRDCTID ,`product_name`,`product_category`,`product_subcategory`,`product_code`,`product_weight`,`gst_flag`,`service_tax`,`discount`,`product_gender`,`product_description`,`product_total_price`,`product_thumb_image` FROM `products`)PRODUCTS ON ORDERDATA.`product_id` = PRODUCTS.PRDCTID ";
  

      
    
        $result = $this->execute_query($sql);

        $adminLists = array();

        if ($this->get_num_rows($result) > 0)

        {

            if ($paginate == "N")

            {

                while ($row = $result->fetch_assoc())
                {

                    $adminLists[] = $row;

                }

            }

            else

            {

                global $num_rows, $p, $start, $list, $other_params, $num, $page;

                $list = ROW_PER_PAGE;

                $num_rows = $this->get_num_rows($result);

                $p = isset($_REQUEST['p']) ? trim($_REQUEST['p']) : 1;

                $num = ceil($num_rows / $list);

                $page = CUR_PAGE_NAME;

                $start = $list * ($p - 1);

                $i = 0;

                while ($row = $this->fetch_data($result))

                {

                    if ($i >= $start && $i < ($start + $list))

                    {

                        $adminLists[] = $row;

                    }

                    $i++;

                }

            }

            return $adminLists;

        }

        else

        {

            return 0;

        }

    }


	public function delete_Order($id)

    {

         $sql = "UPDATE `orders` SET
		       `order_status`= '0'
		        WHERE  `id` = '$id'
				";
			
			
        $con = $this->con;

        return $result = $con->query($sql);

    }


		public function add_product_rating($user_id, $product_id, $feedback,$stars,$approve_stats,$created)

    {

        $sql = "INSERT INTO `product_rating` SET 
                    `user_id` = '$user_id',
                    `product_id` = '$product_id',
                    `feedback` = '$feedback',                             
                    `stars` = '$stars',                             
                    `approve_stats` = '$approve_stats',                             
                    `created` = '$created',                         
                    `delflag` = 'N'                  
                    ";
			
			
        $con = $this->con;

        return $result = $con->query($sql);

    }


   public function getratingExistsByprdctId($product_id)

    {

        $sql = "SELECT * FROM `product_rating` WHERE `product_id` = '$product_id' AND `approve_stats`= '1' AND `delflag` ='N' " ;
        
       

        $con = $this->con;

        $result = $con->query($sql);

        if ($result->num_rows > 0)

        {

            $rslt = $result->fetch_array(MYSQLI_ASSOC);

            return $rslt;

        }

        else

        {

            return "0";

        }

    }

	 public function getAvgratingExistsByprdctId($product_id)

    {

        $sql = "SELECT AVG(stars) AS average_rating FROM `product_rating` WHERE `product_id` = '$product_id' AND `approve_stats`= '1' AND `delflag` ='N' " ;

        $con = $this->con;

        $result = $con->query($sql);

        if ($result->num_rows > 0)

        {

            $rslt = $result->fetch_array(MYSQLI_ASSOC);

            return $rslt;

        }

        else

        {

            return "0";

        }

    }

	public function getstarcountByprdctId($product_id,$stars)

    {

        $sql = "SELECT COUNT(stars) AS star_count FROM `product_rating` WHERE `product_id` = '$product_id' AND `approve_stats`= '1' AND `delflag` ='N' AND `stars` = '$stars' " ;

        $con = $this->con;

        $result = $con->query($sql);

        if ($result->num_rows > 0)

        {

            $rslt = $result->fetch_array(MYSQLI_ASSOC);

            return $rslt;

        }

        else

        {

            return "0";

        }

    }


 public function UserFeedbacklist($userid,$product_id, $paginate = "N")
 {

   $sql = "SELECT `feedback`,`stars` FROM `product_rating` WHERE `user_id`='$userid' AND `product_id` = '$product_id'";
  

      
    
        $result = $this->execute_query($sql);

        $adminLists = array();

        if ($this->get_num_rows($result) > 0)

        {

            if ($paginate == "N")

            {

                while ($row = $result->fetch_assoc())
                {

                    $adminLists[] = $row;

                }

            }

            else

            {

                global $num_rows, $p, $start, $list, $other_params, $num, $page;

                $list = ROW_PER_PAGE;

                $num_rows = $this->get_num_rows($result);

                $p = isset($_REQUEST['p']) ? trim($_REQUEST['p']) : 1;

                $num = ceil($num_rows / $list);

                $page = CUR_PAGE_NAME;

                $start = $list * ($p - 1);

                $i = 0;

                while ($row = $this->fetch_data($result))

                {

                    if ($i >= $start && $i < ($start + $list))

                    {

                        $adminLists[] = $row;

                    }

                    $i++;

                }

            }

            return $adminLists;

        }

        else

        {

            return 0;

        }

    }


 public function OverallFeedbacklist($userid,$product_id, $paginate = "N")
 {

   $sql = "SELECT `user_id`,`feedback`,`stars` FROM `product_rating` WHERE `user_id` != '$userid' AND `product_id` = '$product_id' AND `approve_stats`= '1' AND `delflag` ='N'";
  

      
    
        $result = $this->execute_query($sql);

        $adminLists = array();

        if ($this->get_num_rows($result) > 0)

        {

            if ($paginate == "N")

            {

                while ($row = $result->fetch_assoc())
                {

                    $adminLists[] = $row;

                }

            }

            else

            {

                global $num_rows, $p, $start, $list, $other_params, $num, $page;

                $list = ROW_PER_PAGE;

                $num_rows = $this->get_num_rows($result);

                $p = isset($_REQUEST['p']) ? trim($_REQUEST['p']) : 1;

                $num = ceil($num_rows / $list);

                $page = CUR_PAGE_NAME;

                $start = $list * ($p - 1);

                $i = 0;

                while ($row = $this->fetch_data($result))

                {

                    if ($i >= $start && $i < ($start + $list))

                    {

                        $adminLists[] = $row;

                    }

                    $i++;

                }

            }

            return $adminLists;

        }

        else

        {

            return 0;

        }

    }



	public function empty_card_place_order($user_id)

    {

         $sql = "UPDATE `add_to_cart` SET
		       `delflag`= 'Y'
		        WHERE `user_id` = '$user_id'
				";
				
				
			
			
        $con = $this->con;

        return $result = $con->query($sql);

    }

   
   	public function UserCheckOldPassword($userid,$oldpassword)

    {

        $sql = "SELECT * FROM `user` WHERE `id` = '$userid' AND `password` = '$oldpassword'";


        $con = $this->con;

        $result = $con->query($sql);

        if ($result->num_rows > 0)

        {

            $rslt = $result->fetch_array(MYSQLI_ASSOC);

            return $rslt;

        }

        else

        {

            return "0";

        }

    }
   
   	public function updateUserPassword($newpassword,$user_id)

    {

         $sql = "UPDATE `user` SET
		       `password`= '$newpassword'
		        WHERE `id` = '$user_id'
				";
			
			
        $con = $this->con;

        return $result = $con->query($sql);

    }
    
    
    
 public function UserOrderlistWithProduct($userid, $paginate = "N")
	{

   $sql = "SELECT
    order_id,
    order_code,
    `order_total`,
    `order_status`,
    `order_payment_type`,
    `order_transaction_id`,
    `order_invoice`,
    `created`,
    `full_name`,
    `mobile_number`,
    `pincode`,
    `flat_house_no`,
    `area_street`,
    `landmark`,
    `town_city`,
    `state`,
    `product_name`,
    `product_thumb_image`,
    `product_description`
FROM
    (
    SELECT
        *
    FROM
        (
   
        SELECT
            `id` AS order_id,
            `order_id` AS order_code,
            `order_total`,
            `order_address`,
            `order_status`,
            `order_payment_type`,
            `order_transaction_id`,
            `order_invoice`,
            `created`
        FROM
            `orders`
        WHERE
            `user_id` = '$userid'
    ) ORDERDATA
INNER JOIN(
    SELECT `id` AS address_id,
        `full_name`,
        `mobile_number`,
        `pincode`,
        `flat_house_no`,
        `area_street`,
        `landmark`,
        `town_city`,
        `state`
    FROM
        `user_address`
) ADDRESSDETAILS
ON
    ORDERDATA.`order_address` = ADDRESSDETAILS.address_id
) ORDERADDRESS
INNER JOIN(
    SELECT `order_id` AS ORDEPRDUCTID,
        `product_id` AS ORDERPRDUCTPRDUCTID
    FROM
        `order_products`
) ORDERPRODUCTSDETAILS ON  ORDERADDRESS.order_id = ORDERPRODUCTSDETAILS.ORDEPRDUCTID
INNER JOIN
(
        SELECT `id` AS PRDUCTID,
        `product_name`,
        `product_thumb_image`,
        `product_description`
    FROM
        `products`
    ) PRODUCTDETAILS
ON
    ORDERPRODUCTSDETAILS.ORDERPRDUCTPRDUCTID = PRODUCTDETAILS.PRDUCTID  ";
   
  
  

      
    
        $result = $this->execute_query($sql);

        $adminLists = array();

        if ($this->get_num_rows($result) > 0)

        {

            if ($paginate == "N")

            {

                while ($row = $result->fetch_assoc())
                {

                    $adminLists[] = $row;

                }

            }

            else

            {

                global $num_rows, $p, $start, $list, $other_params, $num, $page;

                $list = ROW_PER_PAGE;

                $num_rows = $this->get_num_rows($result);

                $p = isset($_REQUEST['p']) ? trim($_REQUEST['p']) : 1;

                $num = ceil($num_rows / $list);

                $page = CUR_PAGE_NAME;

                $start = $list * ($p - 1);

                $i = 0;

                while ($row = $this->fetch_data($result))

                {

                    if ($i >= $start && $i < ($start + $list))

                    {

                        $adminLists[] = $row;

                    }

                    $i++;

                }

            }

            return $adminLists;

        }

        else

        {

            return 0;

        }

    }
    
    
    
       	 public function Create_Invoice($invoice_id,$order_id, $total, $invoice_amount,$due,$created)
         {
        $sql = "INSERT INTO `invoice` SET 
                    `invoice_id` = '$invoice_id',
                    `order_id` = '$order_id',
                    `total` = '$total',
                    `invoice_amount` = '$invoice_amount',
                    `due` = '$due',                 
                    `created` = '$created' ,                                               
                    `delflag` = 'N'                  
                    ";			
        $con = $this->con;
        return $result = $con->query($sql);
    }
    
    
     	 public function update_Invoice($invoice_id,$id)

    {

        $sql = "UPDATE `invoice` SET 
                    `invoice_id` = '$invoice_id'  WHERE `id` = '$id'
                    
                    ";
			
        $con = $this->con;

        return $result = $con->query($sql);

    }
    
    public function InvoiceLists($start_date,$end_date,$invoice,$product_code,$order_id,$upperLimit,$lowerLimit,$order,$paginate = "N")
	{

   $sql = "
    SELECT
     `invoice_id`,
    `total`,
    `invoice_amount`,
    `invoice_pdf`,
    `due`,
    `OID` AS orderId,
    `order_status`,
    `order_payment_type`,
    `order_transaction_id`,
    `order_type`,
    `product_quantity`,
    `product_total`,
    `product_name`,
    `product_code`,
    `user_name`,
    `phone_no`,
    `full_name`,
    `mobile_number`,
    `pincode`,
    `flat_house_no`,
    `area_street`,
    `landmark`,
    `town_city`,
    `state`
    FROM
        (
        SELECT
            *
        FROM
            (
            SELECT
                *
            FROM
                (
                SELECT
                    *
                FROM
                    (
                    SELECT
                        *
                    FROM
                        (
                        SELECT
                            *
                        FROM
                            `invoice`
                        WHERE
                            `delflag` = 'N'";
                            
                       if(!empty($start_date) && !empty($end_date))
                       {
					   	$sql .= "AND date(`created`) >= '$start_date  AND date(`created`) <= '$end_date ";
					   }
			           if(!empty($start_date) && empty($end_date))
			           {
					   	$sql .= "AND date(`created`) = '$start_date";
					   } 
					    if(!empty($end_date) && empty($start_date))
			           {
					   	$sql .= "AND date(`created`) = '$end_date";
					   }
					     if(!empty($invoice))
			           {
					   	$sql .= "AND `invoice_id` LIKE '%".$invoice."%' ";
					   }          
                            
               $sql .= ") INVOICE
               INNER  JOIN(
                    SELECT
                        `id` AS ORDERID,
                        `user_id`,
                        `order_id` AS OID,
                        `order_address`,
                        `order_status`,
                        `order_payment_type`,
                        `order_transaction_id`,
                        `order_type`
                    FROM
                        `orders` WHERE `delflag` = 'N'";
                
                 if(!empty($order_id))
			           {
					   	$sql .= "AND `order_id` LIKE '%".$order_id."%' ";
					   }     
                
         $sql .= ")  ORDERS
            ON
                INVOICE.`order_id` = ORDERS.ORDERID
                ) ORDERINVOICE
            LEFT OUTER JOIN(
                SELECT
                    `order_id` AS ORDRPRDCTID,
                    `product_id`,
                    `product_quantity`,
                    `product_total`
                FROM
                    `order_products`
            ) ORDERPRODUCTS
        ON
            ORDERPRODUCTS.ORDRPRDCTID = ORDERINVOICE.ORDERID
            ) ORDERPRODUCTSJOIN
        LEFT OUTER JOIN(
            SELECT
                `product_name`,
                `product_code`,
                `id` AS PIID
            FROM
                `products` WHERE `delflag` = 'N'";
                
                 if(!empty($product_code))
			           {
					   	$sql .= "AND `product_code` LIKE '%".$product_code."%' ";
					   }     
                
         $sql .= ") PRODUCTS
    ON
        ORDERPRODUCTSJOIN.`product_id` = PRODUCTS.PIID
        ) PRODUCTTABLEJOIN
    LEFT OUTER JOIN(
        SELECT
            `id` AS UID,
            `user_name`,
            `phone_no`,
            `email`
        FROM
            `user`
    ) USERS
ON
    USERS.UID = PRODUCTTABLEJOIN.`user_id`
    ) USERSJOIN
LEFT OUTER JOIN(
    SELECT
        `id` AS ADDRESSID,
        `full_name`,
        `mobile_number`,
        `pincode`,
        `flat_house_no`,
        `area_street`,
        `landmark`,
        `town_city`,
        `state`
    FROM
        `user_address`
) USERADDRESS
ON
    USERADDRESS.ADDRESSID = USERSJOIN.`order_address` ORDER BY `id` $order  LIMIT $upperLimit, $lowerLimit ";
    
    
    

  

      
    
        $result = $this->execute_query($sql);

        $adminLists = array();

        if ($this->get_num_rows($result) > 0)

        {

            if ($paginate == "N")

            {

                while ($row = $result->fetch_assoc())
                {

                    $adminLists[] = $row;

                }

            }

            else

            {

                global $num_rows, $p, $start, $list, $other_params, $num, $page;

                $list = ROW_PER_PAGE;

                $num_rows = $this->get_num_rows($result);

                $p = isset($_REQUEST['p']) ? trim($_REQUEST['p']) : 1;

                $num = ceil($num_rows / $list);

                $page = CUR_PAGE_NAME;

                $start = $list * ($p - 1);

                $i = 0;

                while ($row = $this->fetch_data($result))

                {

                    if ($i >= $start && $i < ($start + $list))

                    {

                        $adminLists[] = $row;

                    }

                    $i++;

                }

            }

            return $adminLists;

        }

        else

        {

            return 0;

        }

    }

		public function productListAdmin($paginate = "N")
	{

        $sql = "SELECT `id`,`product_name`,`product_code` FROM `products` WHERE `delflag`  = 'N' ";

      

        $result = $this->execute_query($sql);

        $adminLists = array();

        if ($this->get_num_rows($result) > 0)

        {

            if ($paginate == "N")

            {

                while ($row = $result->fetch_assoc())
                {

                    $adminLists[] = $row;

                }

            }

            else

            {

                global $num_rows, $p, $start, $list, $other_params, $num, $page;

                $list = ROW_PER_PAGE;

                $num_rows = $this->get_num_rows($result);

                $p = isset($_REQUEST['p']) ? trim($_REQUEST['p']) : 1;

                $num = ceil($num_rows / $list);

                $page = CUR_PAGE_NAME;

                $start = $list * ($p - 1);

                $i = 0;

                while ($row = $this->fetch_data($result))

                {

                    if ($i >= $start && $i < ($start + $list))

                    {

                        $adminLists[] = $row;

                    }

                    $i++;

                }

            }

            return $adminLists;

        }

        else

        {

            return 0;

        }

    }
    
    
    
    public function admin_Login($user_email, $password)
    {

        $sql = "SELECT * FROM `user` WHERE

                    `email`='$user_email'

                    AND `password`='$password'

                    AND `delflag`='N'
                    

                    ";

        $con = $this->con;

        $result = $con->query($sql);

        if ($result->num_rows > 0)

        {

            $rslt = $result->fetch_array(MYSQLI_ASSOC);

            return $rslt;

        }

        else

        {

            return "0";

        }

    }
   
}

?>