-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 13, 2022 at 06:44 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `trackndtrace`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `cat_id` varchar(255) NOT NULL,
  `category_name` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `delflag` char(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `user_id`, `cat_id`, `category_name`, `created`, `delflag`) VALUES
(1, 0, 'd41d8cd98f00b204e9800998ecf8427e', 'test_123_category', '2022-10-12 12:41:34', 'N'),
(2, 0, 'b79b53ca718525b71f19e2b3cf8bc4eb', 'test_12456_category', '2022-10-12 12:51:20', 'N'),
(3, 0, '31665522095', 'test1_category', '2022-10-12 02:31:47', 'N'),
(4, 0, '41665533676', 'test0_category', '2022-10-12 05:44:36', 'N'),
(5, 3, '51665677416', 'category1', '2022-10-13 09:40:16', 'N'),
(6, 3, '61665678753', 'category1.2', '2022-10-13 10:02:45', 'N');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` varchar(255) NOT NULL,
  `category_id` varchar(255) NOT NULL,
  `subcategory_id` varchar(255) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_image` text NOT NULL,
  `created` datetime NOT NULL,
  `delflag` char(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `user_id`, `product_id`, `category_id`, `subcategory_id`, `product_name`, `product_image`, `created`, `delflag`) VALUES
(1, 0, 'prtete11665530053', '31665522095', '31665522143', 'productone', 'http://localhost/pwc/trackndtrace/product_images/img1665530049.png', '2022-10-12 05:22:09', 'Y'),
(2, 0, 'prtete21665530070', '31665522095', '31665522143', 'productthree', 'http://localhost/pwc/trackndtrace/product_images/img1665530759.png', '2022-10-12 04:55:59', 'N'),
(3, 0, 'prtete31665534528', '31665522095', '31665522143', 'productthreee', 'http://localhost/pwc/trackndtrace/product_images/img1665534528.png', '2022-10-12 05:58:48', 'N'),
(4, 3, 'prtete41665678779', '31665522095', '31665522143', 'productthreee', 'http://localhost/trackndtrace/product_images/img1665678779.png', '2022-10-13 10:02:59', 'N'),
(5, 3, 'prtete51665678788', '31665522095', '31665522143', 'productthreee1.1', 'http://localhost/trackndtrace/product_images/img1665678799.png', '2022-10-13 10:03:19', 'N');

-- --------------------------------------------------------

--
-- Table structure for table `product_attributes`
--

CREATE TABLE `product_attributes` (
  `id` int(11) NOT NULL,
  `product_id` varchar(255) NOT NULL,
  `attributes` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `delflag` char(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product_attributes`
--

INSERT INTO `product_attributes` (`id`, `product_id`, `attributes`, `created`, `delflag`) VALUES
(1, 'prtete11665530053', 'test_value', '2022-10-12 04:44:09', 'Y'),
(2, 'prtete11665530053', 'test_value', '2022-10-12 04:44:09', 'Y'),
(3, 'prtete11665530053', 'test_value', '2022-10-12 04:44:09', 'Y'),
(4, 'prtete21665530070', 'test_value', '2022-10-12 04:44:30', 'Y'),
(5, 'prtete21665530070', 'test_value', '2022-10-12 04:44:30', 'Y'),
(6, 'prtete21665530070', 'test_value', '2022-10-12 04:44:30', 'Y'),
(7, 'prtete21665530070', 'test_value', '2022-10-12 04:55:36', 'Y'),
(8, 'prtete21665530070', 'test_value', '2022-10-12 04:55:36', 'Y'),
(9, 'prtete21665530070', 'test_value', '2022-10-12 04:55:36', 'Y'),
(10, 'prtete21665530070', 'test_value', '2022-10-12 04:55:59', 'N'),
(11, 'prtete21665530070', 'test_value', '2022-10-12 04:55:59', 'N'),
(12, 'prtete21665530070', 'test_value', '2022-10-12 04:55:59', 'N'),
(13, 'prtete31665534528', 'test_value', '2022-10-12 05:58:48', 'N'),
(14, 'prtete31665534528', 'test_value', '2022-10-12 05:58:48', 'N'),
(15, 'prtete31665534528', 'test_value', '2022-10-12 05:58:48', 'N'),
(16, 'prtete41665678779', 'test_value', '2022-10-13 10:02:59', 'N'),
(17, 'prtete41665678779', 'test_value', '2022-10-13 10:02:59', 'N'),
(18, 'prtete41665678779', 'test_value', '2022-10-13 10:02:59', 'N'),
(19, 'prtete51665678788', 'test_value', '2022-10-13 10:03:08', 'Y'),
(20, 'prtete51665678788', 'test_value', '2022-10-13 10:03:08', 'Y'),
(21, 'prtete51665678788', 'test_value', '2022-10-13 10:03:08', 'Y'),
(22, 'prtete51665678788', 'test_value', '2022-10-13 10:03:19', 'N'),
(23, 'prtete51665678788', 'test_value', '2022-10-13 10:03:19', 'N'),
(24, 'prtete51665678788', 'test_value', '2022-10-13 10:03:19', 'N');

-- --------------------------------------------------------

--
-- Table structure for table `states`
--

CREATE TABLE `states` (
  `id` int(11) NOT NULL,
  `state_code` varchar(255) NOT NULL,
  `state_name` varchar(255) NOT NULL,
  `zone` varchar(255) NOT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  `delflag` char(1) NOT NULL DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `states`
--

INSERT INTO `states` (`id`, `state_code`, `state_name`, `zone`, `created`, `delflag`) VALUES
(1, 'AN', 'Andaman & Nicobar', 'South Zone', '2022-10-05 13:28:53', 'N'),
(2, 'AP', 'Andhra Pradesh', 'South Zone', '2022-10-05 13:28:53', 'N'),
(3, 'AR', 'Arunachal Pradesh', 'East Zone', '2022-10-05 13:28:53', 'N'),
(4, 'AS', 'Assam', 'East Zone', '2022-10-05 13:28:53', 'N'),
(5, 'BR', 'Bihar', 'East Zone', '2022-10-05 13:28:53', 'N'),
(6, 'CG', 'Chandigarh', 'North Zone', '2022-10-05 13:28:53', 'N'),
(7, 'CH', 'Chhattisgarh', 'East Zone', '2022-10-05 13:28:53', 'N'),
(8, 'DN', 'Dadra & Nagar Haveli', 'West Zone', '2022-10-05 13:28:53', 'N'),
(9, 'DD', 'Daman & Diu', 'West Zone', '2022-10-05 13:28:53', 'N'),
(10, 'DL', 'Delhi', 'North Zone', '2022-10-05 13:28:53', 'N'),
(11, 'GA', 'Goa', 'West Zone', '2022-10-05 13:28:53', 'N'),
(12, 'GJ', 'Gujarat', 'West Zone', '2022-10-05 13:28:53', 'N'),
(13, 'HR', 'Haryana', 'North Zone', '2022-10-05 13:28:53', 'N'),
(14, 'HP', 'Himachal Pradesh', 'North Zone', '2022-10-05 13:28:53', 'N'),
(15, 'JK', 'Jammu & Kashmir', 'North Zone', '2022-10-05 13:28:53', 'N'),
(16, 'JH', 'Jharkhand', 'East Zone', '2022-10-05 13:28:53', 'N'),
(17, 'KA', 'Karnataka', 'South Zone', '2022-10-05 13:28:53', 'N'),
(18, 'KL', 'Kerala', 'South Zone', '2022-10-05 13:28:53', 'N'),
(19, 'LA', 'Ladakh', 'North Zone', '2022-10-05 13:28:53', 'N'),
(20, 'LD', 'Lakshadweep', 'South Zone', '2022-10-05 13:28:53', 'N'),
(21, 'MP', 'Madhya Pradesh', 'West Zone', '2022-10-05 13:28:53', 'N'),
(22, 'MH', 'Maharashtra', 'West Zone', '2022-10-05 13:28:53', 'N'),
(23, 'MN', 'Manipur', 'East Zone', '2022-10-05 13:28:53', 'N'),
(24, 'MG', 'Meghalaya', 'East Zone', '2022-10-05 13:28:53', 'N'),
(25, 'MZ', 'Mizoram', 'East Zone', '2022-10-05 13:28:53', 'N'),
(26, 'NL', 'Nagaland', 'East Zone', '2022-10-05 13:28:53', 'N'),
(27, 'OD', 'Odisha', 'East Zone', '2022-10-05 13:28:53', 'N'),
(28, 'PY', 'Puducherry', 'South Zone', '2022-10-05 13:28:53', 'N'),
(29, 'PB', 'Punjab', 'North Zone', '2022-10-05 13:28:53', 'N'),
(30, 'RJ', 'Rajasthan', 'West Zone', '2022-10-05 13:28:53', 'N'),
(31, 'SK', 'Sikkim', 'East Zone', '2022-10-05 13:28:53', 'N'),
(32, 'TN', 'Tamil Nadu', 'South Zone', '2022-10-05 13:28:53', 'N'),
(33, 'TL', 'Telangana', 'South Zone', '2022-10-05 13:28:53', 'N'),
(34, 'TR', 'Tripura', 'East Zone', '2022-10-05 13:28:53', 'N'),
(35, 'UP', 'Uttar Pradesh', 'North Zone', '2022-10-05 13:28:53', 'N'),
(36, 'UK', 'Uttarakhand', 'North Zone', '2022-10-05 13:28:53', 'N'),
(37, 'WB', 'West Bengal', 'East Zone', '2022-10-05 13:28:53', 'N');

-- --------------------------------------------------------

--
-- Table structure for table `subcategory`
--

CREATE TABLE `subcategory` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `category_id` varchar(255) NOT NULL,
  `subcat_id` varchar(255) NOT NULL,
  `subcategory_name` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `delflag` char(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subcategory`
--

INSERT INTO `subcategory` (`id`, `user_id`, `category_id`, `subcat_id`, `subcategory_name`, `created`, `delflag`) VALUES
(1, 0, 'b79b53ca718525b71f19e2b3cf8bc4eb', '59baa0645c20df1da68608e845403eca', 'test_12456_subcategory', '2022-10-12 02:10:59', 'N'),
(2, 0, 'b79b53ca718525b71f19e2b3cf8bc4eb', 'b79b53ca718525b71f19e2b3cf8bc4eb', 'test_subcategory_u', '2022-10-12 02:27:50', 'N'),
(3, 0, '31665522095', '31665522143', 'test_subcategoryu', '2022-10-12 02:32:53', 'N'),
(4, 0, 'b79b53ca718525b71f19e2b3cf8bc4eb', '41665534183', 'test_subcategory_ua', '2022-10-12 05:53:03', 'N'),
(5, 3, '61665678753', '51665678837', 'test_subcategory_1.2', '2022-10-13 10:04:07', 'N');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `user_token` varchar(255) NOT NULL,
  `user_fname` varchar(255) NOT NULL,
  `user_lname` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_phone` varchar(255) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `user_role` char(1) NOT NULL,
  `state` varchar(255) NOT NULL,
  `zone` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `delflag` char(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_token`, `user_fname`, `user_lname`, `user_email`, `user_phone`, `user_password`, `user_role`, `state`, `zone`, `created`, `modified`, `delflag`) VALUES
(1, '59baa0645c20df1da68608e845403eca', 'test1fname', 'test1lname', 'test1@gmail.com', '7001043723', '3f7702267b86b3eefada8021238cd406', '1', 'AN', 'South Zone', '2022-10-05 08:21:26', '2022-10-05 08:21:26', 'N'),
(2, '6de95d6f84188f9ea2d997e59e40c20a', 'test2fname', 'test2lname', 'test2@gmail.com', '7001043711', '1955d9fea757089cbe68d1fee8ea3107', '1', 'AN', 'South Zone', '2022-10-05 08:26:22', '2022-10-05 08:26:22', 'N'),
(3, '6def363a75c53ed7e2bf6683fcb624b7', 'test2fname', 'test2lname', 'test212@gmail.com', '7001043212', '1955d9fea757089cbe68d1fee8ea3107', '1', 'AN', 'South Zone', '2022-10-12 06:11:48', '2022-10-12 06:11:48', 'N');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_attributes`
--
ALTER TABLE `product_attributes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `states`
--
ALTER TABLE `states`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subcategory`
--
ALTER TABLE `subcategory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `product_attributes`
--
ALTER TABLE `product_attributes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `states`
--
ALTER TABLE `states`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `subcategory`
--
ALTER TABLE `subcategory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
